<?php
// File: forum_view_posts.php
// Menampilkan semua postingan/komentar dalam satu topik untuk moderasi.

session_start();
// --- Pengecekan Keamanan ---
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../html/login.php");
    exit;
}

include '../config/db_connect.php';

$topic_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$topic = null;
$posts = [];
$error_message = '';
$success_message = '';

if (isset($_GET['success']) && $_GET['success'] == 'post_deleted') {
    $success_message = 'Komentar berhasil dihapus!';
}

if ($topic_id > 0) {
    try {
        // --- 1. Ambil Detail Topik ---
        $stmt_topic = $pdo->prepare("SELECT id, title FROM forum_topics WHERE id = ?");
        $stmt_topic->execute([$topic_id]);
        $topic = $stmt_topic->fetch();

        if (!$topic) {
            $error_message = "Topik tidak ditemukan.";
        } else {
            // --- 2. Ambil Semua Postingan dalam Topik (Termasuk post awal) ---
            $stmt_posts = $pdo->prepare("
                SELECT 
                    p.id AS post_id, 
                    p.content, 
                    p.created_at, 
                    u.name AS user_name,
                    u.id_users AS user_id
                FROM forum_posts p
                JOIN users u ON p.user_id = u.id_users
                WHERE p.topic_id = ?
                ORDER BY p.created_at ASC
            ");
            $stmt_posts->execute([$topic_id]);
            $posts = $stmt_posts->fetchAll();
        }
    } catch (\PDOException $e) {
        $error_message = "Gagal mengambil data: " . $e->getMessage();
    }
} else {
    $error_message = "ID Topik tidak valid.";
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moderasi Postingan Topik - BloomBelly Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        body {
            background-color: #f8f9fa;
        }

        .sidebar {
            background-color: #343a40;
            min-height: 100vh;
            color: white;
            width: 250px;
        }

        .sidebar .nav-link {
            color: #ccc;
        }

        .sidebar .nav-link.active,
        .sidebar .nav-link:hover {
            color: white;
            background-color: #0d6efd;
        }

        .post-card {
            border-left: 3px solid #0d6efd;
            margin-bottom: 15px;
        }

        .post-first {
            border-left: 3px solid #28a744;
        }
    </style>
</head>

<body>

    <div class="d-flex">
        <div class="sidebar p-3 d-flex flex-column">
            <h4 class="text-white mb-4">BloomBelly Admin</h4>
            <nav class="nav nav-pills flex-column">
                <a class="nav-link" href="index.php">Dashboard</a>
                <a class="nav-link" href="articles.php">Articles Management</a>
                <a class="nav-link active" href="forum.php">Management Forum</a>
                <a class="nav-link" href="#">Users Management</a>
                <a class="nav-link" href="#">Detail User</a>
            </nav>
            <a class="mt-auto nav-link text-danger" href="../html/logout.php">Logout</a>
        </div>

        <div class="flex-grow-1 p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Moderasi Postingan Forum</h2>
                <a href="forum.php" class="btn btn-secondary">← Kembali ke Daftar Topik</a>
            </div>

            <?php if ($error_message): ?>
                <div class="alert alert-danger"><?php echo $error_message; ?></div>
            <?php endif; ?>

            <?php if ($success_message): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo $success_message; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if ($topic): ?>
                <div class="card shadow-sm mb-4">
                    <div class="card-body bg-light">
                        <h4>Topik yang Dimoderasi: <strong><?php echo htmlspecialchars($topic['title']); ?></strong></h4>
                        <p class="text-muted mb-0">Total Postingan: <?php echo count($posts); ?></p>
                    </div>
                </div>

                <div class="posts-list">
                    <?php
                    $post_counter = 0;
                    foreach ($posts as $post):
                        $post_counter++;
                        $is_first_post = ($post_counter == 1);
                    ?>
                        <div class="card shadow-sm post-card <?php echo $is_first_post ? 'post-first' : ''; ?>">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <div>
                                        <small class="text-muted">
                                            <?php if ($is_first_post): ?>
                                                <span class="badge bg-success">TOPIC STARTER</span>
                                            <?php else: ?>
                                                <span class="badge bg-info">KOMENTAR</span>
                                            <?php endif; ?>
                                            <i class="far fa-clock ms-2"></i> <?php echo date('d M Y, H:i', strtotime($post['created_at'])); ?>
                                        </small>
                                        <h6 class="mt-1 mb-0">Oleh: <strong><?php echo htmlspecialchars($post['user_name']); ?></strong> (ID User: <?php echo $post['user_id']; ?>)</h6>
                                    </div>
                                    <div class="flex-shrink-0">
                                        <form method="POST" action="forum_delete_post.php" style="display:inline-block;">
                                            <input type="hidden" name="post_id" value="<?php echo $post['post_id']; ?>">
                                            <input type="hidden" name="topic_id" value="<?php echo $topic_id; ?>">
                                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus postingan ini?');">
                                                <i class="fas fa-trash"></i> Hapus Post
                                            </button>
                                        </form>
                                    </div>
                                </div>
                                <hr>
                                <p><?php echo nl2br(htmlspecialchars($post['content'])); ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <?php if (empty($posts)): ?>
                    <div class="alert alert-info text-center">Topik ini belum memiliki postingan/komentar.</div>
                <?php endif; ?>

            <?php endif; ?>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>