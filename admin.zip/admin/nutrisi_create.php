<?php
session_start();
// --- Pengecekan Keamanan ---
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../html/login.php");
    exit;
}

include '../config/db_connect.php';

$error_message = '';
$success_message = '';
$max_minggu = 40; // Batas maksimum minggu kehamilan

// --- Proses Form Submission ---
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $minggu_ke = (int)$_POST['minggu_ke'];
    $kandungan_nutrisi = trim($_POST['kandungan_nutrisi']);
    $makanan_rekomendasi = trim($_POST['makanan_rekomendasi']);
    $manfaat = trim($_POST['manfaat']);
    $makanan_dihindari = trim($_POST['makanan_dihindari']);

    // Validasi sederhana
    if ($minggu_ke < 1 || $minggu_ke > $max_minggu || empty($kandungan_nutrisi)) {
        $error_message = "Minggu kehamilan harus antara 1-{$max_minggu} dan Kandungan Nutrisi wajib diisi.";
    } else {
        try {
            // Cek apakah data untuk minggu tersebut sudah ada (karena ada UNIQUE KEY di minggu_ke)
            $stmt_check = $pdo->prepare("SELECT COUNT(id_nutrisi) FROM nutrisi WHERE minggu_ke = ?");
            $stmt_check->execute([$minggu_ke]);
            if ($stmt_check->fetchColumn() > 0) {
                $error_message = "Data nutrisi untuk Minggu Ke-{$minggu_ke} sudah ada. Silakan edit data yang sudah ada.";
            } else {
                // Query untuk memasukkan data baru
                $sql = "INSERT INTO nutrisi (minggu_ke, kandungan_nutrisi, makanan_rekomendasi, manfaat, makanan_dihindari) 
                        VALUES (?, ?, ?, ?, ?)";

                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    $minggu_ke,
                    $kandungan_nutrisi,
                    $makanan_rekomendasi,
                    $manfaat,
                    $makanan_dihindari
                ]);

                $success_message = "Data Nutrisi Minggu Ke-{$minggu_ke} berhasil ditambahkan!";
                // Redirect ke halaman utama data management setelah berhasil
                header("Location: data_management.php?success=nutrisi_added");
                exit;
            }
        } catch (\PDOException $e) {
            $error_message = "Gagal menyimpan data: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Nutrisi - BloomBelly Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        body {
            background-color: #f8f9fa;
        }

        .sidebar {
            background-color: #343a40;
            min-height: 100vh;
            color: white;
            width: 250px;
        }

        .sidebar .nav-link {
            color: #ccc;
        }

        .sidebar .nav-link.active,
        .sidebar .nav-link:hover {
            color: white;
            background-color: #0d6efd;
        }
    </style>
</head>

<body>

    <div class="d-flex">
        <div class="sidebar p-3 d-flex flex-column">
            <h4 class="text-white mb-4">BloomBelly Admin</h4>
            <nav class="nav nav-pills flex-column">
                <a class="nav-link" href="index.php">Dashboard</a>
                <a class="nav-link" href="articles.php">Articles Management</a>
                <a class="nav-link" href="forum.php">Management Forum</a>
                <a class="nav-link active" href="data_management.php">Management Data</a>
                <a class="nav-link" href="users.php">Users Management</a>
                <a class="nav-link" href="user_detail.php">Detail User</a>
            </nav>
            <a class="mt-auto nav-link text-danger" href="../html/logout.php">Logout</a>
        </div>

        <div class="flex-grow-1 p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Tambah Data Nutrisi</h2>
                <a href="data_management.php" class="btn btn-secondary">← Kembali</a>
            </div>

            <div class="card shadow-sm">
                <div class="card-body">

                    <?php if ($error_message): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    <?php if ($success_message): ?>
                        <div class="alert alert-success"><?php echo $success_message; ?></div>
                    <?php endif; ?>

                    <form method="POST" action="nutrisi_create.php">

                        <div class="mb-3">
                            <label for="minggu_ke" class="form-label">Minggu Kehamilan *</label>
                            <input type="number" class="form-control" id="minggu_ke" name="minggu_ke" min="1" max="<?php echo $max_minggu; ?>" required value="<?php echo htmlspecialchars($_POST['minggu_ke'] ?? ''); ?>">
                            <small class="form-text text-muted">Masukkan angka antara 1 sampai <?php echo $max_minggu; ?>.</small>
                        </div>

                        <div class="mb-3">
                            <label for="kandungan_nutrisi" class="form-label">Kandungan Nutrisi Utama *</label>
                            <textarea class="form-control" id="kandungan_nutrisi" name="kandungan_nutrisi" rows="3" required><?php echo htmlspecialchars($_POST['kandungan_nutrisi'] ?? ''); ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="makanan_rekomendasi" class="form-label">Makanan Rekomendasi</label>
                            <textarea class="form-control" id="makanan_rekomendasi" name="makanan_rekomendasi" rows="3"><?php echo htmlspecialchars($_POST['makanan_rekomendasi'] ?? ''); ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="manfaat" class="form-label">Manfaat Nutrisi</label>
                            <textarea class="form-control" id="manfaat" name="manfaat" rows="3"><?php echo htmlspecialchars($_POST['manfaat'] ?? ''); ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="makanan_dihindari" class="form-label">Makanan yang Harus Dihindari</label>
                            <textarea class="form-control" id="makanan_dihindari" name="makanan_dihindari" rows="3"><?php echo htmlspecialchars($_POST['makanan_dihindari'] ?? ''); ?></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary">Simpan Data Nutrisi</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>