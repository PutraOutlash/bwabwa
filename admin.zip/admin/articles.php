<?php
// File: articles.php
// Menampilkan daftar artikel menggunakan layout global.

include 'layout/security_check.php';

$pageTitle = "Articles Management";

// Variabel untuk pesan sukses (jika redirect dari halaman create/edit)
$success_message = '';
if (isset($_GET['success'])) {
    if ($_GET['success'] == 'created') {
        $success_message = 'Artikel baru berhasil ditambahkan!';
    } elseif ($_GET['success'] == 'updated') {
        $success_message = 'Artikel berhasil diperbarui!';
    } elseif ($_GET['success'] == 'deleted') {
        $success_message = 'Artikel berhasil dihapus.';
    }
}

// --- 3. Query Data Statistik Articles ---
$published_count = $pdo->query("SELECT COUNT(id_articles) AS total FROM articles WHERE status = 'published'")->fetchColumn();
$draft_count = $pdo->query("SELECT COUNT(id_articles) AS total FROM articles WHERE status = 'draft'")->fetchColumn();

// --- Placeholder/Simulasi untuk growth rate ---
$published_growth = '+5 this month';
$draft_review = '2 needs review';
$deleted_count = 3;
$deleted_growth = '-1 this week';


// --- 4. Query untuk Tabel Daftar Artikel ---
$stmt = $pdo->query("
    SELECT 
        a.id_articles, 
        a.title, 
        a.short_description,
        a.author, 
        a.status, 
        a.created_at, 
        u.name AS user_name 
    FROM articles a
    LEFT JOIN users u ON a.user_id = u.id_users
    ORDER BY a.created_at DESC
");
$articles = $stmt->fetchAll();
?>

<?php include 'layout/header_admin.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">Manage Articles</h4>
    <a href="article_create.php" class="btn btn-primary">➕ Add New Article</a>
</div>

<?php if ($success_message): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo $success_message; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<div class="row mb-4 g-3">
    <div class="col-md-4">
        <div class="card card-stats shadow-sm border-0" style="border-left: 5px solid #28a744;">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-auto">
                        <div class="icon icon-shape bg-success text-white rounded-circle shadow">
                            <i class="fas fa-check"></i>
                        </div>
                    </div>
                    <div class="col">
                        <h6 class="card-title text-uppercase text-muted mb-2">Published Articles</h6>
                        <h1 class="display-4 mb-0"><?php echo $published_count; ?></h1>
                    </div>
                </div>
                <p class="mt-3 mb-0 text-sm">
                    <span class="text-success me-2">↑ <?php echo $published_growth; ?></span>
                </p>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card card-stats shadow-sm border-0" style="border-left: 5px solid #ffc107;">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-auto">
                        <div class="icon icon-shape bg-warning text-white rounded-circle shadow">
                            <i class="fas fa-edit"></i>
                        </div>
                    </div>
                    <div class="col">
                        <h6 class="card-title text-uppercase text-muted mb-2">Draft Articles</h6>
                        <h1 class="display-4 mb-0"><?php echo $draft_count; ?></h1>
                    </div>
                </div>
                <p class="mt-3 mb-0 text-sm">
                    <span class="text-warning me-2">📝 <?php echo $draft_review; ?></span>
                </p>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card card-stats shadow-sm border-0" style="border-left: 5px solid #dc3545;">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-auto">
                        <div class="icon icon-shape bg-danger text-white rounded-circle shadow">
                            <i class="fas fa-trash"></i>
                        </div>
                    </div>
                    <div class="col">
                        <h6 class="card-title text-uppercase text-muted mb-2">Deleted Articles</h6>
                        <h1 class="display-4 mb-0"><?php echo $deleted_count; ?></h1>
                    </div>
                </div>
                <p class="mt-3 mb-0 text-sm">
                    <span class="text-danger me-2">↓ <?php echo $deleted_growth; ?></span>
                </p>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th>Article</th>
                        <th>Author</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($articles as $article): ?>
                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($article['title']); ?></strong><br>
                                <small class="text-muted"><?php echo htmlspecialchars($article['short_description']); ?></small>
                            </td>
                            <td><?php echo htmlspecialchars($article['author']); ?></td>
                            <td><?php echo date('Y-m-d', strtotime($article['created_at'])); ?></td>
                            <td>
                                <span class="badge bg-<?php echo ($article['status'] == 'published' ? 'success' : 'warning'); ?>">
                                    <?php echo ucfirst($article['status']); ?>
                                </span>
                            </td>
                            <td>
                                <a href="article_edit.php?id=<?php echo $article['id_articles']; ?>" class="btn btn-sm btn-info text-white">Edit</a>
                                <form method="POST" action="article_delete.php" style="display:inline-block;">
                                    <input type="hidden" name="id" value="<?php echo $article['id_articles']; ?>">
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus artikel ini?');">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($articles)): ?>
                        <tr>
                            <td colspan="5" class="text-center">Belum ada artikel yang tersedia.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'layout/footer_admin.php'; ?>