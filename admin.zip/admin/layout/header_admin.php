<?php
// File: layout/header_admin.php

// Pastikan variabel $pageTitle diatur oleh file yang memanggil
$pageTitle = $pageTitle ?? "Dashboard Admin"; 
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?> - BloomBelly Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <style>
        body { background-color: #f8f9fa; }
        .sidebar { background-color: #343a40; min-height: 100vh; color: white; width: 250px; }
        .sidebar .nav-link { color: #ccc; }
        /* Menggunakan $current_page untuk menentukan link aktif */
        .sidebar .nav-link.active, .sidebar .nav-link:hover { color: white; background-color: #0d6efd; }
    </style>
</head>
<body>

<div class="d-flex">
    <div class="sidebar p-3 d-flex flex-column">
        <h4 class="text-white mb-4">BloomBelly Admin</h4>
        <nav class="nav nav-pills flex-column">
            <?php 
                $currentPage = basename($_SERVER['PHP_SELF']);
            ?>
            
            <a class="nav-link <?php echo ($currentPage == 'dashboard.php' ? 'active' : ''); ?>" href="dashboard.php"><i class="fas fa-home me-2"></i> Dashboard</a>
            
            <a class="nav-link <?php echo ($currentPage == 'articles.php' || $currentPage == 'article_create.php' || $currentPage == 'article_edit.php' ? 'active' : ''); ?>" href="articles.php"><i class="fas fa-newspaper me-2"></i> Articles Management</a>
            
            <a class="nav-link <?php echo ($currentPage == 'forum.php' || $currentPage == 'forum_view_posts.php' ? 'active' : ''); ?>" href="forum.php"><i class="fas fa-comments me-2"></i> Management Forum</a>
            
            <a class="nav-link <?php echo ($currentPage == 'users.php' || $currentPage == 'user_detail.php' ? 'active' : ''); ?>" href="users.php"><i class="fas fa-users me-2"></i> Users Management</a>
            
            <a class="nav-link <?php echo ($currentPage == 'data_management.php' || $currentPage == 'nutrisi_create.php' || $currentPage == 'nutrisi_edit.php' ? 'active' : ''); ?>" href="data_management.php"><i class="fas fa-database me-2"></i> Management Data</a>
            
        </nav>
        <a class="mt-auto nav-link text-danger" href="../html/logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a> 
    </div>
    <div class="flex-grow-1 p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><?php echo htmlspecialchars($pageTitle); ?></h2> 
            <span class="text-muted"><?php echo htmlspecialchars($_SESSION['email'] ?? 'admin@bloombelly.com'); ?></span>
        </div>