<?php
// File: layout/security_check.php
// Berisi sesi, pengecekan role, dan koneksi database

session_start();
// --- Pengecekan Keamanan (Wajib!) ---
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../html/login.php");
    exit;
}
// Pastikan include path ini benar, menuju ke folder config/db_connect.php
include '../config/db_connect.php';
