<?php
session_start();
// --- Pengecekan Keamanan ---
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../html/login.php");
    exit;
}

// Pastikan include path ini benar
include '../config/db_connect.php';

$error_message = '';
$success_message = '';
$user_id = $_SESSION['user_id']; // ID admin yang sedang login

// --- 1. Ambil Data Kategori ---
$stmt_cat = $pdo->query("SELECT id, name FROM article_categories ORDER BY name ASC");
$categories = $stmt_cat->fetchAll();

// --- 2. Proses Form Submission ---
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = trim($_POST['title']);
    $category_id = (int)$_POST['category_id'];
    $short_description = trim($_POST['short_description']);
    $external_url = trim($_POST['external_url']);
    $author = trim($_POST['author']);
    $status = $_POST['status'];

    // Slug otomatis dari title
    $slug = strtolower(str_replace(' ', '-', $title));

    // Periksa apakah semua field wajib terisi
    if (empty($title) || empty($short_description) || empty($external_url) || empty($author) || $category_id == 0) {
        $error_message = "Semua field wajib diisi dan Kategori harus dipilih.";
    } else {
        try {
            // Tangani tanggal publikasi
            $published_at = ($status == 'published') ? date('Y-m-d H:i:s') : NULL;

            // Query untuk memasukkan data artikel baru
            $sql = "INSERT INTO articles (user_id, category_id, title, slug, short_description, external_url, author, status, created_at, published_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $user_id,
                $category_id,
                $title,
                $slug,
                $short_description,
                $external_url,
                $author,
                $status,
                $published_at
            ]);

            $success_message = "Artikel **{$title}** berhasil ditambahkan!";
            // Redirect ke halaman daftar artikel setelah berhasil
            header("Location: articles.php?success=created");
            exit;
        } catch (\PDOException $e) {
            // Untuk debugging, gunakan die()
            $error_message = "Gagal menyimpan data: " . $e->getMessage();
            // Jika ini di production, ganti dengan: $error_message = "Gagal menyimpan data.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Artikel - BloomBelly Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .sidebar {
            background-color: #343a40;
            min-height: 100vh;
            color: white;
            width: 250px;
        }

        .sidebar .nav-link {
            color: #ccc;
        }

        .sidebar .nav-link.active,
        .sidebar .nav-link:hover {
            color: white;
            background-color: #0d6efd;
        }
    </style>
</head>

<body>

    <div class="d-flex">
        <div class="sidebar p-3 d-flex flex-column">
            <h4 class="text-white mb-4">BloomBelly Admin</h4>
            <nav class="nav nav-pills flex-column">
                <a class="nav-link" href="index.php">Dashboard</a>
                <a class="nav-link active" href="articles.php">Articles Management</a>
                <a class="nav-link" href="#">Management Forum</a>
                <a class="nav-link" href="#">Users Management</a>
                <a class="nav-link" href="#">Detail User</a>
            </nav>
            <a class="mt-auto nav-link text-danger" href="../html/logout.php">Logout</a>
        </div>

        <div class="flex-grow-1 p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Tambah Artikel Baru</h2>
                <a href="articles.php" class="btn btn-secondary">← Kembali ke Daftar Artikel</a>
            </div>

            <div class="card shadow-sm">
                <div class="card-body">

                    <?php if ($error_message): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    <?php if ($success_message): ?>
                        <div class="alert alert-success"><?php echo $success_message; ?></div>
                    <?php endif; ?>

                    <form method="POST" action="article_create.php">

                        <div class="mb-3">
                            <label for="title" class="form-label">Judul Artikel *</label>
                            <input type="text" class="form-control" id="title" name="title" required value="<?php echo htmlspecialchars($_POST['title'] ?? ''); ?>">
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="category_id" class="form-label">Kategori *</label>
                                <select class="form-select" id="category_id" name="category_id" required>
                                    <option value="">Pilih Kategori</option>
                                    <?php foreach ($categories as $cat): ?>
                                        <option value="<?php echo $cat['id']; ?>">
                                            <?php echo htmlspecialchars($cat['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="status" class="form-label">Status *</label>
                                <select class="form-select" id="status" name="status" required>
                                    <option value="draft">Draft</option>
                                    <option value="published">Published</option>
                                </select>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="author" class="form-label">Nama Penulis *</label>
                            <input type="text" class="form-control" id="author" name="author" required value="<?php echo htmlspecialchars($_POST['author'] ?? $_SESSION['name'] ?? ''); ?>">
                            <small class="form-text text-muted">Nama yang akan ditampilkan sebagai penulis.</small>
                        </div>

                        <div class="mb-3">
                            <label for="external_url" class="form-label">External URL (Sumber Asli) *</label>
                            <input type="url" class="form-control" id="external_url" name="external_url" required value="<?php echo htmlspecialchars($_POST['external_url'] ?? ''); ?>">
                            <small class="form-text text-muted">Link ke sumber artikel eksternal.</small>
                        </div>

                        <div class="mb-3">
                            <label for="short_description" class="form-label">Deskripsi Singkat *</label>
                            <textarea class="form-control" id="short_description" name="short_description" rows="5" required><?php echo htmlspecialchars($_POST['short_description'] ?? ''); ?></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary">Simpan Artikel</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>