<?php
// File: forum.php
// Menampilkan daftar topik forum untuk moderasi, menggunakan layout modular.

// 1. PANGGIL SECURITY CHECK (Menggantikan session_start(), cek role, dan include db)
include 'layout/security_check.php';

// 2. SET JUDUL HALAMAN
$pageTitle = "Management Forum";
$admin_email = $_SESSION['email'] ?? 'admin@bloombelly.com';

// Variabel untuk pesan sukses jika ada (setelah delete, dll)
$success_message = '';
if (isset($_GET['success']) && $_GET['success'] == 'topic_deleted') {
    $success_message = 'Topik forum berhasil dihapus!';
}

// --- Query untuk Mengambil Daftar Topik Forum ---
$stmt = $pdo->query("
    SELECT 
        t.id AS topic_id, 
        t.title AS topic_title, 
        t.created_at,
        u.name AS starter_name,
        s.name AS section_name,
        (SELECT COUNT(p.id) FROM forum_posts p WHERE p.topic_id = t.id) AS post_count
    FROM forum_topics t
    JOIN users u ON t.user_id = u.id_users
    LEFT JOIN forum_sections s ON t.section_id = s.id
    ORDER BY t.created_at DESC
");
$topics = $stmt->fetchAll();
?>

<?php include 'layout/header_admin.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><?php echo $pageTitle; ?></h2>
    <span class="text-muted"><?php echo htmlspecialchars($admin_email); ?></span>
</div>

<?php if ($success_message): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo $success_message; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-header bg-white">
        <h4>Daftar Topik Diskusi</h4>
        <small class="text-muted">Gunakan 'Lihat Post' untuk moderasi komentar di dalam topik.</small>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th>Topik</th>
                        <th>Section</th>
                        <th>Dibuat Oleh</th>
                        <th>Total Post</th>
                        <th>Tanggal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($topics as $topic): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($topic['topic_title']); ?></strong></td>
                            <td><?php echo htmlspecialchars($topic['section_name'] ?? 'Umum'); ?></td>
                            <td><?php echo htmlspecialchars($topic['starter_name']); ?></td>
                            <td><span class="badge bg-primary"><?php echo $topic['post_count']; ?></span></td>
                            <td><?php echo date('d M Y', strtotime($topic['created_at'])); ?></td>
                            <td>
                                <a href="forum_view_posts.php?id=<?php echo $topic['topic_id']; ?>" class="btn btn-sm btn-warning text-white">Lihat Post</a>

                                <form method="POST" action="forum_delete.php" style="display:inline-block;">
                                    <input type="hidden" name="topic_id" value="<?php echo $topic['topic_id']; ?>">
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('PERINGATAN: Menghapus topik akan menghapus SEMUA postingan di dalamnya. Lanjutkan?');">Hapus Topik</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($topics)): ?>
                        <tr>
                            <td colspan="6" class="text-center">Belum ada topik forum yang dibuat.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'layout/footer_admin.php'; ?>