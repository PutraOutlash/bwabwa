<?php
// File: data_management.php
// Menampilkan daftar Nutrisi Ibu Hamil.

session_start();
// --- Pengecekan Keamanan ---
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../html/login.php");
    exit;
}

include '../config/db_connect.php';

$search_term = $_GET['search'] ?? '';
$minggu_filter = $_GET['minggu'] ?? '';
$success_message = '';

// Handling Success Messages
if (isset($_GET['success']) && $_GET['success'] == 'nutrisi_added') {
    $success_message = 'Data Nutrisi berhasil ditambahkan.';
}

// --- Query untuk Mengambil Data Nutrisi ---
$where_clauses = [];
$params = [];

// Filter Pencarian (Contoh: mencari berdasarkan kandungan nutrisi)
if (!empty($search_term)) {
    $where_clauses[] = "(kandungan_nutrisi LIKE ? OR makanan_rekomendasi LIKE ?)";
    $params[] = "%$search_term%";
    $params[] = "%$search_term%";
}

// Filter Minggu
if (!empty($minggu_filter)) {
    $where_clauses[] = "minggu_ke = ?";
    $params[] = $minggu_filter;
}

$sql = "SELECT id_nutrisi, minggu_ke, kandungan_nutrisi, makanan_rekomendasi, manfaat, makanan_dihindari FROM nutrisi";
if (!empty($where_clauses)) {
    $sql .= " WHERE " . implode(" AND ", $where_clauses);
}
$sql .= " ORDER BY minggu_ke ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$nutrisi_list = $stmt->fetchAll();

// Ambil semua minggu yang unik untuk dropdown filter
$all_minggu = $pdo->query("SELECT DISTINCT minggu_ke FROM nutrisi ORDER BY minggu_ke ASC")->fetchAll(PDO::FETCH_COLUMN);

?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Management Data - BloomBelly Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        body {
            background-color: #f8f9fa;
        }

        .sidebar {
            background-color: #343a40;
            min-height: 100vh;
            color: white;
            width: 250px;
        }

        .sidebar .nav-link {
            color: #ccc;
        }

        .sidebar .nav-link.active,
        .sidebar .nav-link:hover {
            color: white;
            background-color: #0d6efd;
        }
    </style>
</head>

<body>

    <div class="d-flex">
        <div class="sidebar p-3 d-flex flex-column">
            <h4 class="text-white mb-4">BloomBelly Admin</h4>
            <nav class="nav nav-pills flex-column">
                <a class="nav-link" href="index.php">Dashboard</a>
                <a class="nav-link" href="articles.php">Articles Management</a>
                <a class="nav-link" href="forum.php">Management Forum</a>
                <a class="nav-link active" href="data_management.php">Management Data</a>
                <a class="nav-link" href="users.php">Users Management</a>
                <a class="nav-link" href="user_detail.php">Detail User</a>
            </nav>
            <a class="mt-auto nav-link text-danger" href="../html/logout.php">Logout</a>
        </div>

        <div class="flex-grow-1 p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Management Data</h2>
                <span class="text-muted">admin@bloombelly.com</span>
            </div>

            <h4 class="mb-4">Data Management</h4>

            <ul class="nav nav-pills mb-3" id="dataTab" role="tablist">
                <li class="nav-item">
                    <a class="btn btn-primary active me-2" id="nutrisi-tab" data-bs-toggle="pill" href="#nutrisi" role="tab">Nutrisi Ibu Hamil</a>
                </li>
                <li class="nav-item">
                    <a class="btn btn-secondary" id="perkembangan-tab" data-bs-toggle="pill" href="#perkembangan" role="tab">Perkembangan Janin</a>
                </li>
            </ul>

            <?php if ($success_message): ?>
                <div class="alert alert-success"><?php echo $success_message; ?></div>
            <?php endif; ?>

            <div class="tab-content" id="dataTabContent">

                <div class="tab-pane fade show active" id="nutrisi" role="tabpanel" aria-labelledby="nutrisi-tab">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <form method="GET" action="data_management.php" class="row g-3 align-items-center mb-4">
                                <div class="col-md-5">
                                    <input type="text" name="search" class="form-control" placeholder="Cari nutrisi, makanan rekomendasi..." value="<?php echo htmlspecialchars($search_term); ?>">
                                </div>
                                <div class="col-md-3">
                                    <select name="minggu" class="form-select">
                                        <option value="">Semua Minggu</option>
                                        <?php foreach ($all_minggu as $minggu): ?>
                                            <option value="<?php echo $minggu; ?>" <?php echo ($minggu == $minggu_filter) ? 'selected' : ''; ?>>
                                                Minggu Ke-<?php echo $minggu; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-4 text-end">
                                    <button type="submit" class="btn btn-info me-2">Filter</button>
                                    <a href="nutrisi_create.php" class="btn btn-primary">+ Tambah Nutrisi</a>
                                </div>
                            </form>

                            <div class="table-responsive">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <tr>
                                            <th>Minggu</th>
                                            <th>Kandungan Nutrisi</th>
                                            <th>Makanan Rekomendasi</th>
                                            <th>Manfaat</th>
                                            <th>Makanan Dihindari</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($nutrisi_list as $nutrisi): ?>
                                            <tr>
                                                <td><span class="badge bg-secondary">Minggu <?php echo $nutrisi['minggu_ke']; ?></span></td>
                                                <td><?php echo nl2br(htmlspecialchars(substr($nutrisi['kandungan_nutrisi'], 0, 50) . (strlen($nutrisi['kandungan_nutrisi']) > 50 ? '...' : ''))); ?></td>
                                                <td><?php echo nl2br(htmlspecialchars(substr($nutrisi['makanan_rekomendasi'], 0, 50) . (strlen($nutrisi['makanan_rekomendasi']) > 50 ? '...' : ''))); ?></td>
                                                <td><?php echo nl2br(htmlspecialchars(substr($nutrisi['manfaat'], 0, 50) . (strlen($nutrisi['manfaat']) > 50 ? '...' : ''))); ?></td>
                                                <td><?php echo nl2br(htmlspecialchars(substr($nutrisi['makanan_dihindari'], 0, 50) . (strlen($nutrisi['makanan_dihindari']) > 50 ? '...' : ''))); ?></td>
                                                <td>
                                                    <a href="nutrisi_edit.php?id=<?php echo $nutrisi['id_nutrisi']; ?>" class="btn btn-sm btn-info text-white">Edit</a>
                                                    <form method="POST" action="nutrisi_delete.php" style="display:inline-block;">
                                                        <input type="hidden" name="id" value="<?php echo $nutrisi['id_nutrisi']; ?>">
                                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Hapus data Nutrisi Minggu <?php echo $nutrisi['minggu_ke']; ?>?');">Hapus</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                        <?php if (empty($nutrisi_list)): ?>
                                            <tr>
                                                <td colspan="6" class="text-center">Tidak ada data nutrisi yang ditemukan.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="tab-pane fade" id="perkembangan" role="tabpanel" aria-labelledby="perkembangan-tab">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <p>Halaman untuk mengelola data perkembangan janin per minggu (memerlukan implementasi tabel `perkembangan` di masa depan).</p>
                            <a href="perkembangan_create.php" class="btn btn-primary">+ Tambah Data Perkembangan</a>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>