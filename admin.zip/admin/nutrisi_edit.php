<?php
session_start();
// --- Pengecekan Keamanan ---
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../html/login.php");
    exit;
}

include '../config/db_connect.php';

$error_message = '';
$success_message = '';
$nutrisi = null;
$max_minggu = 40;
$nutrisi_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// --- 1. Proses Form Submission (UPDATE) ---
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nutrisi_id_post = (int)$_POST['nutrisi_id'];
    $minggu_ke = (int)$_POST['minggu_ke'];
    $kandungan_nutrisi = trim($_POST['kandungan_nutrisi']);
    $makanan_rekomendasi = trim($_POST['makanan_rekomendasi']);
    $manfaat = trim($_POST['manfaat']);
    $makanan_dihindari = trim($_POST['makanan_dihindari']);

    // Validasi sederhana
    if ($minggu_ke < 1 || $minggu_ke > $max_minggu || empty($kandungan_nutrisi)) {
        $error_message = "Minggu kehamilan harus antara 1-{$max_minggu} dan Kandungan Nutrisi wajib diisi.";
    } else {
        try {
            // Cek duplikasi: Pastikan minggu_ke yang di-update tidak bertabrakan dengan data lain
            $stmt_check = $pdo->prepare("SELECT COUNT(id_nutrisi) FROM nutrisi WHERE minggu_ke = ? AND id_nutrisi != ?");
            $stmt_check->execute([$minggu_ke, $nutrisi_id_post]);
            if ($stmt_check->fetchColumn() > 0) {
                $error_message = "Data nutrisi untuk Minggu Ke-{$minggu_ke} sudah ada di record lain.";
            } else {
                // Query untuk memperbarui data
                $sql = "UPDATE nutrisi SET 
                            minggu_ke = ?, 
                            kandungan_nutrisi = ?, 
                            makanan_rekomendasi = ?, 
                            manfaat = ?, 
                            makanan_dihindari = ?
                        WHERE id_nutrisi = ?";

                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    $minggu_ke,
                    $kandungan_nutrisi,
                    $makanan_rekomendasi,
                    $manfaat,
                    $makanan_dihindari,
                    $nutrisi_id_post
                ]);

                $success_message = "Data Nutrisi Minggu Ke-{$minggu_ke} berhasil diperbarui!";
                // Redirect ke halaman daftar data management setelah berhasil
                header("Location: data_management.php?success=nutrisi_updated");
                exit;
            }
        } catch (\PDOException $e) {
            $error_message = "Gagal memperbarui data: " . $e->getMessage();
        }
    }
}

// --- 3. Ambil Data yang Akan Diedit ---
if ($nutrisi_id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM nutrisi WHERE id_nutrisi = ?");
    $stmt->execute([$nutrisi_id]);
    $nutrisi = $stmt->fetch();

    if (!$nutrisi) {
        $error_message = "Data nutrisi tidak ditemukan.";
    }
} else if ($_SERVER["REQUEST_METHOD"] != "POST") {
    // Jika tidak ada ID dan bukan post request, redirect
    header("Location: data_management.php");
    exit;
}

// Gunakan data dari database atau dari POST jika ada error saat submit
$data_to_display = $nutrisi;
if ($_SERVER["REQUEST_METHOD"] == "POST" && $nutrisi) {
    $data_to_display = $_POST;
    $data_to_display['id_nutrisi'] = $nutrisi_id;
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Nutrisi - BloomBelly Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .sidebar {
            background-color: #343a40;
            min-height: 100vh;
            color: white;
            width: 250px;
        }

        .sidebar .nav-link {
            color: #ccc;
        }

        .sidebar .nav-link.active,
        .sidebar .nav-link:hover {
            color: white;
            background-color: #0d6efd;
        }
    </style>
</head>

<body>

    <div class="d-flex">
        <div class="sidebar p-3 d-flex flex-column">
            <h4 class="text-white mb-4">BloomBelly Admin</h4>
            <nav class="nav nav-pills flex-column">
                <a class="nav-link" href="index.php">Dashboard</a>
                <a class="nav-link" href="articles.php">Articles Management</a>
                <a class="nav-link" href="forum.php">Management Forum</a>
                <a class="nav-link active" href="data_management.php">Management Data</a>
                <a class="nav-link" href="users.php">Users Management</a>
                <a class="nav-link" href="user_detail.php">Detail User</a>
            </nav>
            <a class="mt-auto nav-link text-danger" href="../html/logout.php">Logout</a>
        </div>

        <div class="flex-grow-1 p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Edit Data Nutrisi (Minggu ke-<?php echo htmlspecialchars($data_to_display['minggu_ke'] ?? 'N/A'); ?>)</h2>
                <a href="data_management.php" class="btn btn-secondary">← Kembali</a>
            </div>

            <div class="card shadow-sm">
                <div class="card-body">

                    <?php if ($error_message): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    <?php if ($success_message): ?>
                        <div class="alert alert-success"><?php echo $success_message; ?></div>
                    <?php endif; ?>
                    <?php if (!$nutrisi && $_SERVER["REQUEST_METHOD"] != "POST"): ?>
                        <div class="alert alert-warning">Data Nutrisi tidak ditemukan.</div>
                    <?php else: ?>

                        <form method="POST" action="nutrisi_edit.php?id=<?php echo $data_to_display['id_nutrisi']; ?>">
                            <input type="hidden" name="nutrisi_id" value="<?php echo $data_to_display['id_nutrisi']; ?>">

                            <div class="mb-3">
                                <label for="minggu_ke" class="form-label">Minggu Kehamilan *</label>
                                <input type="number" class="form-control" id="minggu_ke" name="minggu_ke" min="1" max="<?php echo $max_minggu; ?>" required value="<?php echo htmlspecialchars($data_to_display['minggu_ke'] ?? ''); ?>">
                                <small class="form-text text-muted">Masukkan angka antara 1 sampai <?php echo $max_minggu; ?>.</small>
                            </div>

                            <div class="mb-3">
                                <label for="kandungan_nutrisi" class="form-label">Kandungan Nutrisi Utama *</label>
                                <textarea class="form-control" id="kandungan_nutrisi" name="kandungan_nutrisi" rows="3" required><?php echo htmlspecialchars($data_to_display['kandungan_nutrisi'] ?? ''); ?></textarea>
                            </div>

                            <div class="mb-3">
                                <label for="makanan_rekomendasi" class="form-label">Makanan Rekomendasi</label>
                                <textarea class="form-control" id="makanan_rekomendasi" name="makanan_rekomendasi" rows="3"><?php echo htmlspecialchars($data_to_display['makanan_rekomendasi'] ?? ''); ?></textarea>
                            </div>

                            <div class="mb-3">
                                <label for="manfaat" class="form-label">Manfaat Nutrisi</label>
                                <textarea class="form-control" id="manfaat" name="manfaat" rows="3"><?php echo htmlspecialchars($data_to_display['manfaat'] ?? ''); ?></textarea>
                            </div>

                            <div class="mb-3">
                                <label for="makanan_dihindari" class="form-label">Makanan yang Harus Dihindari</label>
                                <textarea class="form-control" id="makanan_dihindari" name="makanan_dihindari" rows="3"><?php echo htmlspecialchars($data_to_display['makanan_dihindari'] ?? ''); ?></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary">Simpan Perubahan Nutrisi</button>
                        </form>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>