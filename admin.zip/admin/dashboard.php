<?php
// File: dashboard.php (Menggunakan Layout Global)

// 1. PANGGIL SECURITY CHECK (session_start(), cek role, dan include db)
include 'layout/security_check.php'; 

// 2. SET JUDUL HALAMAN
$pageTitle = "Dashboard Overview"; 
$admin_name = $_SESSION['name'] ?? 'Admin'; 
$admin_email = $_SESSION['email'] ?? 'admin@bloombelly.com';

// ==============================================================================
// 3. KODE PHP: LOGIKA DATA OVERVIEW & GRAFIK
// ==============================================================================

// A. TOTAL USERS, ARTICLES, FORUM
$total_users = number_format($pdo->query("SELECT COUNT(id_users) AS total_users FROM users WHERE role = 'user'")->fetchColumn());
$total_articles = number_format($pdo->query("SELECT COUNT(id_articles) AS total_articles FROM articles WHERE status = 'published'")->fetchColumn());
$total_topics = number_format($pdo->query("SELECT COUNT(id) AS total_topics FROM forum_topics")->fetchColumn());


// --- Data Grafik Pertumbuhan Pengguna (12 bulan terakhir) ---
$stmt_growth = $pdo->query("
    SELECT 
        DATE_FORMAT(created_at, '%Y-%m') AS registration_month,
        COUNT(id_users) AS user_count
    FROM 
        users
    WHERE 
        role = 'user' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
    GROUP BY 
        registration_month
    ORDER BY 
        registration_month ASC
");
$growth_data = $stmt_growth->fetchAll();

// Memformat Data untuk Chart.js
$labels = [];
$counts = [];
foreach ($growth_data as $row) {
    $month_label = date('M Y', strtotime($row['registration_month']));
    $labels[] = $month_label;
    $counts[] = $row['user_count'];
}

$json_labels = json_encode($labels);
$json_counts = json_encode($counts);


// --- Logika Persentase Pertumbuhan Bulan Ini vs Bulan Lalu (FIXED QUERY) ---
$current_month = $pdo->query("SELECT COUNT(id_users) AS count FROM users 
    WHERE role = 'user' AND DATE_FORMAT(created_at, '%Y-%m') = DATE_FORMAT(NOW(), '%Y-%m')")->fetchColumn();

$last_month = $pdo->query("SELECT COUNT(id_users) AS count FROM users 
    WHERE role = 'user' AND DATE_FORMAT(created_at, '%Y-%m') = DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 MONTH), '%Y-%m')")->fetchColumn();


$user_growth_percent = 0;
if ($last_month > 0) {
    $user_growth_percent = round((($current_month - $last_month) / $last_month) * 100);
} else if ($current_month > 0) {
    $user_growth_percent = 100;
}

$user_growth_icon = ($user_growth_percent >= 0) ? 'fa-arrow-up' : 'fa-arrow-down';
$user_growth_color = ($user_growth_percent >= 0) ? 'text-success' : 'text-danger';

// Placeholder untuk card lain
$article_growth_percent = 5;
$forum_growth_percent = 8;
?>

<?php include 'layout/header_admin.php'; ?>

<div class="row mb-5">
    <div class="col-md-4">
        <div class="card card-stats shadow-sm border-0" style="border-left: 5px solid #0d6efd;">
            <div class="card-body">
                <h6 class="card-title text-uppercase text-muted mb-2">Total Users</h6>
                <h1 class="display-4 mb-0"><?php echo $total_users; ?></h1>
                <p class="mt-3 mb-0 text-sm">
                    <span class="<?php echo $user_growth_color; ?> me-2">
                        <i class="fas <?php echo $user_growth_icon; ?>"></i> <?php echo abs($user_growth_percent); ?>%
                    </span>
                    <span class="text-nowrap">Sejak bulan lalu</span>
                </p>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card card-stats shadow-sm border-0" style="border-left: 5px solid #28a745;">
            <div class="card-body">
                <h6 class="card-title text-uppercase text-muted mb-2">Total Articles</h6>
                <h1 class="display-4 mb-0"><?php echo $total_articles; ?></h1>
                <p class="mt-3 mb-0 text-sm">
                    <span class="text-success me-2"><i class="fas fa-arrow-up"></i> <?php echo $article_growth_percent; ?>%</span>
                    <span class="text-nowrap">Sejak bulan lalu</span>
                </p>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card card-stats shadow-sm border-0" style="border-left: 5px solid #6f42c1;">
            <div class="card-body">
                <h6 class="card-title text-uppercase text-muted mb-2">Total Forum</h6>
                <h1 class="display-4 mb-0"><?php echo $total_topics; ?></h1>
                <p class="mt-3 mb-0 text-sm">
                    <span class="text-success me-2"><i class="fas fa-arrow-up"></i> <?php echo $forum_growth_percent; ?>%</span>
                    <span class="text-nowrap">Sejak bulan lalu</span>
                </p>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-header bg-white">
                <h5 class="card-title mb-0">Analytics Dashboard</h5>
            </div>
            <div class="card-body">
                <div style="height: 300px;">
                    <canvas id="userGrowthChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-body">
                <h5 class="card-title">Kalender</h5>
                <div class="text-center">
                    <h6>November 2025</h6>
                    <p class="text-muted">... Tampilan kalender placeholder ...</p>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Ambil Data dari PHP yang sudah di-encode ke JSON
    const chartLabels = <?php echo $json_labels; ?>;
    const chartCounts = <?php echo $json_counts; ?>;

    const ctx = document.getElementById('userGrowthChart').getContext('2d');

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: chartLabels,
            datasets: [{
                label: 'Pengguna Baru',
                data: chartCounts,
                backgroundColor: 'rgba(13, 110, 253, 0.5)',
                borderColor: '#0d6efd',
                borderWidth: 3,
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    title: { display: true, text: 'Jumlah Pengguna' },
                    ticks: {
                        callback: function(value) {
                            if (value % 1 === 0) { return value; }
                            return null;
                        }
                    }
                }
            },
            plugins: {
                legend: { display: true, position: 'top' }
            }
        }
    });
</script>
<?php include 'layout/footer_admin.php'; ?>