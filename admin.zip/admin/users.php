<?php
// File: users.php
// Menampilkan daftar pengguna dengan status kehamilan terakhir.

// 1. PANGGIL SECURITY CHECK (Menggantikan session_start(), cek role, dan include db)
include 'layout/security_check.php';

// 2. SET JUDUL HALAMAN
$pageTitle = "Users Management";

// Variabel untuk pesan sukses jika ada (setelah delete/update role)
$success_message = '';
if (isset($_GET['success']) && $_GET['success'] == 'role_updated') {
    $success_message = 'Peran pengguna berhasil diubah!';
} elseif (isset($_GET['success']) && $_GET['success'] == 'action_performed') {
    $success_message = 'Aksi berhasil dijalankan.';
} elseif (isset($_GET['error']) && $_GET['error'] == 'block_placeholder') {
    // Menampilkan pesan placeholder untuk aksi blokir
    $success_message = 'Simulasi: Pengguna ini sudah diblokir.';
}


// --- Query untuk Mengambil Daftar Pengguna (role='user') ---
$stmt = $pdo->query("
    SELECT 
        u.id_users, 
        u.name, 
        u.email, 
        u.username,
        u.created_at,
        u.role,
        t.status AS pregnancy_status,
        t.minggu_kehamilan,
        t.hpl
    FROM users u
    -- Ambil status kehamilan yang aktif (t.aktif = 1)
    LEFT JOIN tracking_kehamilan t ON u.id_users = t.id_users AND t.aktif = 1 
    WHERE u.role = 'user' OR u.role = 'blocked' 
    ORDER BY u.created_at DESC
");
$users = $stmt->fetchAll();
?>

<?php include 'layout/header_admin.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><?php echo $pageTitle; ?></h2>
    <span class="text-muted"><?php echo htmlspecialchars($_SESSION['email'] ?? 'admin@bloombelly.com'); ?></span>
</div>

<?php if ($success_message): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo $success_message; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<div class="card shadow-sm">
    <div class="card-header bg-white">
        <h4>Daftar Pengguna Aplikasi</h4>
        <small class="text-muted">Menampilkan semua pengguna dengan peran 'user'.</small>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama / Username</th>
                        <th>Email</th>
                        <th>Status Kehamilan</th>
                        <th>HPL / Minggu Ke</th>
                        <th>Bergabung</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1;
                    foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($user['name']); ?></strong><br>
                                <small class="text-muted"><?php echo htmlspecialchars($user['username']); ?></small>
                            </td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td>
                                <?php
                                $status = $user['pregnancy_status'] ?? 'Tidak Terdaftar';
                                $badge_color = 'secondary';
                                if ($status == 'hamil')
                                    $badge_color = 'info';
                                else if ($status == 'lahir')
                                    $badge_color = 'success';
                                else if ($status == 'keguguran')
                                    $badge_color = 'danger';
                                ?>
                                <span class="badge bg-<?php echo $badge_color; ?>"><?php echo ucfirst($status); ?></span>
                            </td>
                            <td>
                                <?php if ($user['hpl']): ?>
                                    HPL: <?php echo date('d M Y', strtotime($user['hpl'])); ?><br>
                                    <small class="text-muted">Minggu ke-<?php echo $user['minggu_kehamilan'] ?? '?'; ?></small>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td><?php echo date('d M Y', strtotime($user['created_at'])); ?></td>
                            <td>
                                <a href="user_detail.php?id=<?php echo $user['id_users']; ?>" class="btn btn-sm btn-info text-white">Detail</a>

                                <a href="user_action.php?id=<?php echo $user['id_users']; ?>&action=block"
                                    class="btn btn-sm btn-warning"
                                    onclick="return confirm('Apakah Anda yakin ingin memblokir pengguna ini? Ini akan menonaktifkan akunnya.');">
                                    Blokir
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($users)): ?>
                        <tr>
                            <td colspan="7" class="text-center">Belum ada pengguna terdaftar (role='user').</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'layout/footer_admin.php'; ?>