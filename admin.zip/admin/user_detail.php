<?php
// File: user_detail.php
// Menampilkan detail profil, riwayat kehamilan, dan diary pengguna.

session_start();
// --- Pengecekan Keamanan ---
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../html/login.php");
    exit;
}

include '../config/db_connect.php';

$user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$user = null;
$pregnancies = [];
$diaries = [];
$error_message = '';

if ($user_id > 0) {
    try {
        // --- 1. Ambil Detail Dasar Pengguna ---
        $stmt_user = $pdo->prepare("SELECT id_users, name, email, username, phone, bio, created_at, avatar_url FROM users WHERE id_users = ?");
        $stmt_user->execute([$user_id]);
        $user = $stmt_user->fetch();

        if (!$user) {
            $error_message = "Pengguna tidak ditemukan.";
        } else {
            // --- 2. Ambil Riwayat Tracking Kehamilan ---
            $stmt_preg = $pdo->prepare("SELECT * FROM tracking_kehamilan WHERE id_users = ? ORDER BY dibuat_pada DESC");
            $stmt_preg->execute([$user_id]);
            $pregnancies = $stmt_preg->fetchAll();

            // --- 3. Ambil Riwayat Diary ---
            $stmt_diary = $pdo->prepare("SELECT id_diary, judul, dibuat_pada FROM diary WHERE id_users = ? ORDER BY dibuat_pada DESC");
            $stmt_diary->execute([$user_id]);
            $diaries = $stmt_diary->fetchAll();
        }
    } catch (\PDOException $e) {
        $error_message = "Gagal mengambil data: " . $e->getMessage();
    }
} else {
    $error_message = "ID Pengguna tidak valid.";
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail User: <?php echo htmlspecialchars($user['name'] ?? 'N/A'); ?> - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        body {
            background-color: #f8f9fa;
        }

        .sidebar {
            background-color: #343a40;
            min-height: 100vh;
            color: white;
            width: 250px;
        }

        .sidebar .nav-link {
            color: #ccc;
        }

        .sidebar .nav-link.active,
        .sidebar .nav-link:hover {
            color: white;
            background-color: #0d6efd;
        }

        .profile-img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 50%;
        }
    </style>
</head>

<body>

    <div class="d-flex">
        <div class="sidebar p-3 d-flex flex-column">
            <h4 class="text-white mb-4">BloomBelly Admin</h4>
            <nav class="nav nav-pills flex-column">
                <a class="nav-link" href="index.php">Dashboard</a>
                <a class="nav-link" href="articles.php">Articles Management</a>
                <a class="nav-link" href="forum.php">Management Forum</a>
                <a class="nav-link active" href="users.php">Users Management</a>
                <a class="nav-link" href="user_detail.php">Detail User</a>
            </nav>
            <a class="mt-auto nav-link text-danger" href="../html/logout.php">Logout</a>
        </div>

        <div class="flex-grow-1 p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Detail Pengguna</h2>
                <a href="users.php" class="btn btn-secondary">← Kembali ke Daftar Pengguna</a>
            </div>

            <?php if ($error_message): ?>
                <div class="alert alert-danger"><?php echo $error_message; ?></div>
            <?php endif; ?>

            <?php if ($user): ?>
                <div class="card shadow-sm mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3 text-center">
                                <?php
                                $avatar = $user['avatar_url'] ?? 'placeholder.jpg'; // Ganti placeholder dengan path default Anda
                                // Asumsi avatar_url adalah path relatif dari root proyek, kita pakai path default jika kosong/null
                                if (strpos($avatar, '..') === 0) {
                                    $avatar = substr($avatar, 3); // Hapus ../ jika ada
                                }
                                $avatar_path = (empty($user['avatar_url']) || $user['avatar_url'] == 'placeholder.jpg')
                                    ? '../images/default-avatar.png' // Ganti dengan default avatar Anda
                                    : $avatar;
                                ?>
                                <img src="<?php echo htmlspecialchars($avatar_path); ?>" alt="Avatar" class="profile-img border border-3 p-1">
                                <h4 class="mt-3"><?php echo htmlspecialchars($user['name']); ?></h4>
                                <p class="text-muted">@<?php echo htmlspecialchars($user['username']); ?></p>
                                <a href="user_action.php?id=<?php echo $user['id_users']; ?>&action=promote" class="btn btn-sm btn-outline-success">Promosikan ke Admin</a>
                            </div>
                            <div class="col-md-9">
                                <h5>Informasi Kontak & Akun</h5>
                                <table class="table table-sm table-borderless">
                                    <tr>
                                        <th>ID User</th>
                                        <td><?php echo $user['id_users']; ?></td>
                                    </tr>
                                    <tr>
                                        <th>Email</th>
                                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Telepon</th>
                                        <td><?php echo htmlspecialchars($user['phone'] ?? '-'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Bergabung Sejak</th>
                                        <td><?php echo date('d M Y', strtotime($user['created_at'])); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Bio</th>
                                        <td><?php echo htmlspecialchars($user['bio'] ?? '-'); ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pregnancy-tab" data-bs-toggle="tab" data-bs-target="#pregnancy" type="button" role="tab" aria-controls="pregnancy" aria-selected="true">Riwayat Kehamilan (<?php echo count($pregnancies); ?>)</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="diary-tab" data-bs-toggle="tab" data-bs-target="#diary" type="button" role="tab" aria-controls="diary" aria-selected="false">Diary (<?php echo count($diaries); ?>)</button>
                    </li>
                </ul>

                <div class="tab-content bg-white p-3 border border-top-0 shadow-sm" id="myTabContent">

                    <div class="tab-pane fade show active" id="pregnancy" role="tabpanel" aria-labelledby="pregnancy-tab">
                        <h5>Riwayat Tracking Kehamilan</h5>
                        <div class="table-responsive">
                            <table class="table table-striped table-sm">
                                <thead>
                                    <tr>
                                        <th>Status</th>
                                        <th>HPHT</th>
                                        <th>HPL</th>
                                        <th>Minggu Ke-</th>
                                        <th>Tanggal Kejadian</th>
                                        <th>Aktif</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($pregnancies as $p): ?>
                                        <tr>
                                            <td>
                                                <span class="badge bg-<?php
                                                                        if ($p['status'] == 'hamil') echo 'info';
                                                                        else if ($p['status'] == 'lahir') echo 'success';
                                                                        else if ($p['status'] == 'keguguran') echo 'danger';
                                                                        else echo 'secondary';
                                                                        ?>"><?php echo ucfirst($p['status']); ?></span>
                                            </td>
                                            <td><?php echo date('d M Y', strtotime($p['hpht'])); ?></td>
                                            <td><?php echo date('d M Y', strtotime($p['hpl'])); ?></td>
                                            <td><?php echo $p['minggu_kehamilan'] ?? '-'; ?></td>
                                            <td>
                                                <?php if ($p['status'] == 'lahir'): ?>
                                                    Lahir: <?php echo date('d M Y', strtotime($p['tanggal_lahir'])); ?>
                                                <?php elseif ($p['status'] == 'keguguran'): ?>
                                                    Keguguran: <?php echo date('d M Y', strtotime($p['tanggal_keguguran'])); ?>
                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            </td>
                                            <td><i class="fas fa-<?php echo $p['aktif'] ? 'check text-success' : 'times text-danger'; ?>"></i></td>
                                        </tr>
                                    <?php endforeach; ?>
                                    <?php if (empty($pregnancies)): ?>
                                        <tr>
                                            <td colspan="6" class="text-center">Belum ada riwayat kehamilan yang dicatat.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="diary" role="tabpanel" aria-labelledby="diary-tab">
                        <h5>Daftar Judul Diary</h5>
                        <ul class="list-group list-group-flush">
                            <?php foreach ($diaries as $d): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <span><?php echo htmlspecialchars($d['judul']); ?></span>
                                    <small class="text-muted"><?php echo date('d M Y', strtotime($d['dibuat_pada'])); ?></small>
                                </li>
                            <?php endforeach; ?>
                            <?php if (empty($diaries)): ?>
                                <li class="list-group-item text-center text-muted">Pengguna ini belum memiliki entri diary.</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>

            <?php endif; ?>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>