<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../html/login.php");
    exit;
}

include '../config/db_connect.php';

$pageTitle = "Tambah Data Perkembangan Janin";
$error_message = '';
$max_minggu = 40;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $minggu_ke = (int)$_POST['minggu_ke'];
    $ukuran_bayi = trim($_POST['ukuran_bayi']);
    $perkembangan_terbaru = trim($_POST['perkembangan_terbaru']);
    $tips = trim($_POST['tips']);
    $hal_dihindari = trim($_POST['hal_dihindari']);

    if ($minggu_ke < 1 || $minggu_ke > $max_minggu || empty($ukuran_bayi) || empty($perkembangan_terbaru)) {
        $error_message = "Minggu, Ukuran, dan Perkembangan wajib diisi.";
    } else {
        try {
            $stmt_check = $pdo->prepare("SELECT COUNT(id_perkembangan) FROM perkembangan WHERE minggu_ke = ?");
            $stmt_check->execute([$minggu_ke]);
            if ($stmt_check->fetchColumn() > 0) {
                $error_message = "Data perkembangan untuk Minggu Ke-{$minggu_ke} sudah ada. Silakan edit.";
            } else {
                $sql = "INSERT INTO perkembangan (minggu_ke, ukuran_bayi, perkembangan_terbaru, tips, hal_dihindari) 
                        VALUES (?, ?, ?, ?, ?)";

                $stmt = $pdo->prepare($sql);
                $stmt->execute([$minggu_ke, $ukuran_bayi, $perkembangan_terbaru, $tips, $hal_dihindari]);

                header("Location: data_management.php?success=perkembangan_added");
                exit;
            }
        } catch (\PDOException $e) {
            $error_message = "Gagal menyimpan data: " . $e->getMessage();
        }
    }
}
?>

<?php include 'layout/header_admin.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><?php echo $pageTitle; ?></h2>
    <a href="data_management.php" class="btn btn-secondary">← Kembali</a>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <?php if ($error_message): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <form method="POST" action="perkembangan_create.php">

            <div class="mb-3">
                <label for="minggu_ke" class="form-label">Minggu Kehamilan *</label>
                <input type="number" class="form-control" id="minggu_ke" name="minggu_ke" min="1" max="<?php echo $max_minggu; ?>" required value="<?php echo htmlspecialchars($_POST['minggu_ke'] ?? ''); ?>">
            </div>

            <div class="mb-3">
                <label for="ukuran_bayi" class="form-label">Ukuran Bayi (Contoh: Sebesar Lemon) *</label>
                <input type="text" class="form-control" id="ukuran_bayi" name="ukuran_bayi" required value="<?php echo htmlspecialchars($_POST['ukuran_bayi'] ?? ''); ?>">
            </div>

            <div class="mb-3">
                <label for="perkembangan_terbaru" class="form-label">Perkembangan Terbaru *</label>
                <textarea class="form-control" id="perkembangan_terbaru" name="perkembangan_terbaru" rows="5" required><?php echo htmlspecialchars($_POST['perkembangan_terbaru'] ?? ''); ?></textarea>
            </div>

            <div class="mb-3">
                <label for="tips" class="form-label">Tips untuk Ibu</label>
                <textarea class="form-control" id="tips" name="tips" rows="3"><?php echo htmlspecialchars($_POST['tips'] ?? ''); ?></textarea>
            </div>

            <div class="mb-3">
                <label for="hal_dihindari" class="form-label">Hal yang Harus Dihindari</label>
                <textarea class="form-control" id="hal_dihindari" name="hal_dihindari" rows="3"><?php echo htmlspecialchars($_POST['hal_dihindari'] ?? ''); ?></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Simpan Data Perkembangan</button>
        </form>
    </div>
</div>

<?php include 'layout/footer_admin.php'; ?>