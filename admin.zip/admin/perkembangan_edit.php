<?php
// File: perkembangan_edit.php
// Mengedit data Perkembangan Janin berdasarkan ID

// Panggil Security Check dan Koneksi DB
include 'layout/security_check.php';

$pageTitle = "Edit Data Perkembangan Janin";
$error_message = '';
$success_message = '';
$max_minggu = 40;

// ==============================================================================
// 1. AMBIL ID DAN DATA LAMA
// ==============================================================================

// Pastikan ID perkembangan ada di URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    // Jika tidak ada ID, kembalikan ke halaman manajemen data
    header("Location: data_management.php?error=no_id");
    exit;
}

$id_perkembangan = (int)$_GET['id'];

try {
    // Ambil data lama untuk diisi ke form
    $stmt_fetch = $pdo->prepare("SELECT * FROM perkembangan WHERE id_perkembangan = ?");
    $stmt_fetch->execute([$id_perkembangan]);
    $data = $stmt_fetch->fetch();

    // Jika data tidak ditemukan
    if (!$data) {
        header("Location: data_management.php?error=not_found");
        exit;
    }
} catch (\PDOException $e) {
    die("Gagal mengambil data: " . $e->getMessage());
}


// ==============================================================================
// 2. HANDLE POST (UPDATE DATA)
// ==============================================================================

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $minggu_ke = (int)$_POST['minggu_ke'];
    $ukuran_bayi = trim($_POST['ukuran_bayi']);
    $perkembangan_terbaru = trim($_POST['perkembangan_terbaru']);
    $tips = trim($_POST['tips']);
    $hal_dihindari = trim($_POST['hal_dihindari']);

    // Validasi sederhana
    if ($minggu_ke < 1 || $minggu_ke > $max_minggu || empty($ukuran_bayi) || empty($perkembangan_terbaru)) {
        $error_message = "Minggu, Ukuran, dan Perkembangan wajib diisi.";
    } else {
        // Cek apakah 'minggu_ke' yang baru sudah digunakan oleh data lain
        $stmt_check = $pdo->prepare("SELECT COUNT(id_perkembangan) FROM perkembangan WHERE minggu_ke = ? AND id_perkembangan != ?");
        $stmt_check->execute([$minggu_ke, $id_perkembangan]);

        if ($stmt_check->fetchColumn() > 0) {
            $error_message = "Data perkembangan untuk Minggu Ke-{$minggu_ke} sudah ada pada data lain.";
        } else {
            try {
                // Query UPDATE
                $sql = "UPDATE perkembangan SET 
                            minggu_ke = ?, 
                            ukuran_bayi = ?, 
                            perkembangan_terbaru = ?, 
                            tips = ?, 
                            hal_dihindari = ?
                        WHERE id_perkembangan = ?";

                $stmt = $pdo->prepare($sql);
                $stmt->execute([$minggu_ke, $ukuran_bayi, $perkembangan_terbaru, $tips, $hal_dihindari, $id_perkembangan]);

                // Update data $data agar form terisi dengan nilai baru
                $data = [
                    'minggu_ke' => $minggu_ke,
                    'ukuran_bayi' => $ukuran_bayi,
                    'perkembangan_terbaru' => $perkembangan_terbaru,
                    'tips' => $tips,
                    'hal_dihindari' => $hal_dihindari
                ];

                $success_message = "Data Perkembangan Janin berhasil diperbarui!";
            } catch (\PDOException $e) {
                $error_message = "Gagal memperbarui data: " . $e->getMessage();
            }
        }
    }
}
?>

<?php include 'layout/header_admin.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><?php echo $pageTitle; ?> (Minggu Ke-<?php echo htmlspecialchars($data['minggu_ke']); ?>)</h2>
    <a href="data_management.php" class="btn btn-secondary">← Kembali</a>
</div>

<div class="card shadow-sm">
    <div class="card-body">
        <?php if ($error_message): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <?php if ($success_message): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>

        <form method="POST" action="perkembangan_edit.php?id=<?php echo $id_perkembangan; ?>">

            <div class="mb-3">
                <label for="minggu_ke" class="form-label">Minggu Kehamilan *</label>
                <input type="number" class="form-control" id="minggu_ke" name="minggu_ke" min="1" max="<?php echo $max_minggu; ?>" required value="<?php echo htmlspecialchars($data['minggu_ke']); ?>">
            </div>

            <div class="mb-3">
                <label for="ukuran_bayi" class="form-label">Ukuran Bayi (Contoh: Sebesar Lemon) *</label>
                <input type="text" class="form-control" id="ukuran_bayi" name="ukuran_bayi" required value="<?php echo htmlspecialchars($data['ukuran_bayi']); ?>">
            </div>

            <div class="mb-3">
                <label for="perkembangan_terbaru" class="form-label">Perkembangan Terbaru *</label>
                <textarea class="form-control" id="perkembangan_terbaru" name="perkembangan_terbaru" rows="5" required><?php echo htmlspecialchars($data['perkembangan_terbaru']); ?></textarea>
            </div>

            <div class="mb-3">
                <label for="tips" class="form-label">Tips untuk Ibu</label>
                <textarea class="form-control" id="tips" name="tips" rows="3"><?php echo htmlspecialchars($data['tips']); ?></textarea>
            </div>

            <div class="mb-3">
                <label for="hal_dihindari" class="form-label">Hal yang Harus Dihindari</label>
                <textarea class="form-control" id="hal_dihindari" name="hal_dihindari" rows="3"><?php echo htmlspecialchars($data['hal_dihindari']); ?></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        </form>
    </div>
</div>

<?php include 'layout/footer_admin.php'; ?>