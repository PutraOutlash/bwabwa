<?php
// File: data_management.php
// Menampilkan daftar Nutrisi Ibu Hamil.

// --- PANGGIL SECURITY CHECK dan DB CONNECT ---
include 'layout/security_check.php';

$pageTitle = "Management Data";

$search_term = $_GET['search'] ?? '';
$minggu_filter = $_GET['minggu'] ?? '';
$success_message = '';

// Handling Success Messages
if (isset($_GET['success']) && $_GET['success'] == 'nutrisi_added') {
    $success_message = 'Data Nutrisi berhasil ditambahkan. 🥗';
} elseif (isset($_GET['success']) && $_GET['success'] == 'nutrisi_updated') {
    $success_message = 'Data Nutrisi berhasil diperbarui. ✨';
} elseif (isset($_GET['success']) && $_GET['success'] == 'nutrisi_deleted') {
    $success_message = 'Data Nutrisi berhasil dihapus. 🗑️';
}

// --- Query untuk Mengambil Data Nutrisi ---
$where_clauses = [];
$params = [];

// Filter Pencarian (Contoh: mencari berdasarkan kandungan nutrisi)
if (!empty($search_term)) {
    $where_clauses[] = "(kandungan_nutrisi LIKE ? OR makanan_rekomendasi LIKE ?)";
    $params[] = "%$search_term%";
    $params[] = "%$search_term%";
}

// Filter Minggu
if (!empty($minggu_filter)) {
    $where_clauses[] = "minggu_ke = ?";
    $params[] = $minggu_filter;
}

$sql = "SELECT id_nutrisi, minggu_ke, kandungan_nutrisi, makanan_rekomendasi, manfaat, makanan_dihindari FROM nutrisi";
if (!empty($where_clauses)) {
    $sql .= " WHERE " . implode(" AND ", $where_clauses);
}
$sql .= " ORDER BY minggu_ke ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$nutrisi_list = $stmt->fetchAll();

// Ambil semua minggu yang unik untuk dropdown filter
$all_minggu = $pdo->query("SELECT DISTINCT minggu_ke FROM nutrisi ORDER BY minggu_ke ASC")->fetchAll(PDO::FETCH_COLUMN);

// --- Query untuk Perkembangan Janin (diperlukan untuk konten tab) ---
try {
    $sql_perkembangan = "SELECT id_perkembangan, minggu_ke, deskripsi_janin, ukuran_berat, ukuran_panjang FROM perkembangan_janin ORDER BY minggu_ke ASC";
    $stmt_perkembangan = $pdo->query($sql_perkembangan);
    $perkembangan_list = $stmt_perkembangan->fetchAll();
} catch (\PDOException $e) {
    // Jika tabel belum ada (misalnya), berikan array kosong
    $perkembangan_list = [];
}

?>

<?php include 'layout/header_admin.php'; ?>

<style>
    /* Variabel Warna & Font */
    :root {
        --color-primary: #17a2b8;
        --color-secondary: #6c757d;
        --color-info: #0dcaf0;
        --table-header-bg: #e9ecef;
    }

    /* --- General Styling --- */
    .data-card {
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        border: none;
        overflow: hidden;
    }

    /* --- Tab Styling (Fokus di Sini) --- */
    .data-nav-list .nav-link {
        /* Ubah: Targetkan list nav kustom */
        font-weight: 600;
        color: var(--color-secondary);
        border: none;
        padding: 0.75rem 1.5rem;
        border-radius: 8px 8px 0 0;
        transition: all 0.2s;
        margin-right: 0.5rem;
        background-color: #e9ecef;
    }

    .data-nav-list .nav-link.active {
        color: white;
        background-color: var(--color-primary);
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
    }

    .data-nav-list {
        /* Container utama tab navigation */
        border-bottom: none;
        margin-bottom: 0;
    }

    .tab-content {
        margin-top: 0;
        padding: 2rem;
        background-color: white;
        border-radius: 0 12px 12px 12px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
    }

    /* --- Filter & Search --- */
    .filter-group .form-control,
    .filter-group .form-select {
        border-radius: 8px;
    }

    /* --- Table Styling --- */
    .table-data th {
        background-color: var(--table-header-bg);
        color: #495057;
        font-weight: 700;
        text-transform: uppercase;
        font-size: 0.75rem;
        padding: 1rem 1.5rem;
        letter-spacing: 0.5px;
    }

    .table-data td {
        vertical-align: middle;
        padding: 1rem 1.5rem;
        font-size: 0.9rem;
        border-top: 1px solid #f1f1f1;
    }

    .table-data tbody tr:hover {
        background-color: #f7f9fc;
        box-shadow: inset 3px 0 0 var(--color-primary);
    }

    /* Badge Minggu */
    .badge-minggu {
        background-color: var(--color-primary) !important;
        color: white;
        padding: 0.4em 0.8em;
        border-radius: 4px;
        font-weight: 600;
    }

    .badge-minggu-info {
        /* Badge untuk Perkembangan */
        background-color: var(--color-info) !important;
        color: white;
        padding: 0.4em 0.8em;
        border-radius: 4px;
        font-weight: 600;
    }

    /* Tombol Aksi */
    .btn-action {
        width: 35px;
        height: 35px;
        padding: 0;
        display: inline-flex;
        justify-content: center;
        align-items: center;
        border-radius: 50%;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
</style>

## ⚙️ Management Data Aplikasi

<div class="header-section">
    <h2><i class="fas fa-database me-2 text-primary"></i> Management Data</h2>
    <span class="text-muted"><i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($_SESSION['email'] ?? 'admin@bloombelly.com'); ?></span>
</div>

<ul class="nav data-nav-list mb-0" id="dataTab" role="tablist">
    <li class="nav-item">
        <a class="nav-link active" id="nutrisi-tab" data-bs-toggle="tab" data-bs-target="#nutrisi" href="#nutrisi" role="tab" aria-controls="nutrisi" aria-selected="true">
            <i class="fas fa-utensils me-2"></i> Nutrisi Ibu Hamil
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" id="perkembangan-tab" data-bs-toggle="tab" data-bs-target="#perkembangan" href="#perkembangan" role="tab" aria-controls="perkembangan" aria-selected="false">
            <i class="fas fa-chart-line me-2"></i> Perkembangan Janin
        </a>
    </li>
</ul>

<div class="tab-content" id="dataTabContent">

    <?php if ($success_message): ?>
        <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
            <?php echo $success_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="tab-pane fade show active" id="nutrisi" role="tabpanel" aria-labelledby="nutrisi-tab">
        <h5 class="fw-bold text-secondary mb-4">Daftar Kebutuhan Nutrisi Mingguan</h5>

        <form method="GET" action="data_management.php" class="row g-3 align-items-center mb-5 filter-group">
            <div class="col-lg-5 col-md-5">
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                    <input type="text" name="search" class="form-control" placeholder="Cari kandungan, makanan rekomendasi..." value="<?php echo htmlspecialchars($search_term); ?>">
                </div>
            </div>
            <div class="col-lg-3 col-md-3">
                <select name="minggu" class="form-select">
                    <option value="">Semua Minggu</option>
                    <?php foreach ($all_minggu as $minggu): ?>
                        <option value="<?php echo $minggu; ?>" <?php echo ($minggu == $minggu_filter) ? 'selected' : ''; ?>>
                            Minggu Ke-<?php echo $minggu; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-lg-4 col-md-4 text-end">
                <button type="submit" class="btn btn-info text-white me-3 d-inline-flex align-items-center">
                    <i class="fas fa-filter me-2"></i> Filter
                </button>
                <a href="nutrisi_create.php" class="btn btn-primary d-inline-flex align-items-center">
                    <i class="fas fa-plus me-2"></i> Tambah Nutrisi
                </a>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover table-data align-middle mb-0">
                <thead>
                    <tr>
                        <th style="width: 8%;">Minggu</th>
                        <th style="width: 20%;">Kandungan Nutrisi</th>
                        <th style="width: 20%;">Makanan Rekomendasi</th>
                        <th style="width: 20%;">Manfaat</th>
                        <th style="width: 17%;">Makanan Dihindari</th>
                        <th style="width: 15%;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($nutrisi_list as $nutrisi): ?>
                        <tr>
                            <td><span class="badge badge-minggu"><?php echo $nutrisi['minggu_ke']; ?></span></td>
                            <td><?php echo nl2br(htmlspecialchars(substr($nutrisi['kandungan_nutrisi'], 0, 70) . (strlen($nutrisi['kandungan_nutrisi']) > 70 ? '...' : ''))); ?></td>
                            <td><?php echo nl2br(htmlspecialchars(substr($nutrisi['makanan_rekomendasi'], 0, 70) . (strlen($nutrisi['makanan_rekomendasi']) > 70 ? '...' : ''))); ?></td>
                            <td><?php echo nl2br(htmlspecialchars(substr($nutrisi['manfaat'], 0, 70) . (strlen($nutrisi['manfaat']) > 70 ? '...' : ''))); ?></td>
                            <td><small class="text-danger"><?php echo nl2br(htmlspecialchars(substr($nutrisi['makanan_dihindari'], 0, 70) . (strlen($nutrisi['makanan_dihindari']) > 70 ? '...' : ''))); ?></small></td>
                            <td>
                                <a href="nutrisi_edit.php?id=<?php echo $nutrisi['id_nutrisi']; ?>" class="btn btn-sm btn-info text-white btn-action me-2" title="Edit Data">
                                    <i class="fas fa-pen"></i>
                                </a>
                                <form method="POST" action="nutrisi_delete.php" style="display:inline-block;">
                                    <input type="hidden" name="id" value="<?php echo $nutrisi['id_nutrisi']; ?>">
                                    <button type="submit" class="btn btn-sm btn-danger btn-action" title="Hapus Data" onclick="return confirm('Hapus data Nutrisi Minggu <?php echo $nutrisi['minggu_ke']; ?>?');">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($nutrisi_list)): ?>
                        <tr>
                            <td colspan="6" class="text-center py-4">
                                <i class="fas fa-sad-cry fa-2x text-muted mb-2"></i>
                                <p class="mb-0 text-muted">Tidak ada data nutrisi yang ditemukan untuk filter ini.</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="tab-pane fade" id="perkembangan" role="tabpanel" aria-labelledby="perkembangan-tab">
        <h5 class="fw-bold text-secondary mb-4">Daftar Data Perkembangan Janin Mingguan</h5>

        <div class="text-end mb-4">
            <a href="perkembangan_create.php" class="btn btn-primary d-inline-flex align-items-center">
                <i class="fas fa-plus me-2"></i> Tambah Data Perkembangan
            </a>
        </div>

        <div class="table-responsive">
            <table class="table table-hover table-data align-middle mb-0">
                <thead>
                    <tr>
                        <th style="width: 10%;">Minggu</th>
                        <th style="width: 40%;">Deskripsi Janin</th>
                        <th style="width: 15%;">Berat</th>
                        <th style="width: 15%;">Panjang</th>
                        <th style="width: 20%;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($perkembangan_list as $data): ?>
                        <tr>
                            <td>
                                <span class="badge badge-minggu-info"><?php echo $data['minggu_ke']; ?></span>
                            </td>
                            <td>
                                <?php echo nl2br(htmlspecialchars(substr($data['deskripsi_janin'], 0, 100) . (strlen($data['deskripsi_janin']) > 100 ? '...' : ''))); ?>
                            </td>
                            <td>
                                <i class="fas fa-weight-hanging me-1 text-secondary"></i>
                                <?php echo htmlspecialchars($data['ukuran_berat']); ?>
                            </td>
                            <td>
                                <i class="fas fa-ruler-vertical me-1 text-secondary"></i>
                                <?php echo htmlspecialchars($data['ukuran_panjang']); ?>
                            </td>
                            <td>
                                <a href="perkembangan_edit.php?id=<?php echo $data['id_perkembangan']; ?>"
                                    class="btn btn-sm btn-info text-white btn-action me-2"
                                    title="Edit Data">
                                    <i class="fas fa-pen"></i>
                                </a>
                                <form method="POST" action="perkembangan_delete.php" style="display:inline-block;">
                                    <input type="hidden" name="id" value="<?php echo $data['id_perkembangan']; ?>">
                                    <button type="submit" class="btn btn-sm btn-danger btn-action" title="Hapus Data" onclick="return confirm('Hapus data Perkembangan Minggu <?php echo $data['minggu_ke']; ?>?');">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($perkembangan_list)): ?>
                        <tr>
                            <td colspan="5" class="text-center py-4">
                                <i class="fas fa-baby-carriage fa-2x text-muted mb-2"></i>
                                <p class="mb-0 text-muted">Belum ada data perkembangan janin yang tersedia.</p>
                                <a href="perkembangan_create.php" class="btn btn-outline-primary btn-sm mt-2"><i class="fas fa-plus me-1"></i> Tambah Data Perkembangan</a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php include 'layout/footer_admin.php'; ?>