<?php
// File: articles.php
// Menampilkan daftar artikel menggunakan layout global.

include 'layout/security_check.php';

$pageTitle = "Articles Management";

// Variabel untuk pesan sukses (jika redirect dari halaman create/edit)
$success_message = '';
if (isset($_GET['success'])) {
    if ($_GET['success'] == 'created') {
        $success_message = 'Artikel baru berhasil ditambahkan! 🚀';
    } elseif ($_GET['success'] == 'updated') {
        $success_message = 'Artikel berhasil diperbarui! ✨';
    } elseif ($_GET['success'] == 'deleted') {
        $success_message = 'Artikel berhasil dihapus. 🗑️';
    }
}

// --- 3. Query Data Statistik Articles ---
$published_count = $pdo->query("SELECT COUNT(id_articles) AS total FROM articles WHERE status = 'published'")->fetchColumn();
$draft_count = $pdo->query("SELECT COUNT(id_articles) AS total FROM articles WHERE status = 'draft'")->fetchColumn();

// --- Placeholder/Simulasi untuk growth rate ---
$published_growth = '+5 this month';
$draft_review = '2 needs review';
$deleted_count = 3;
$deleted_growth = '-1 this week';


// --- 4. Query untuk Tabel Daftar Artikel ---
$stmt = $pdo->query("
    SELECT 
        a.id_articles, 
        a.title, 
        a.short_description,
        a.author, 
        a.status, 
        a.created_at, 
        u.name AS user_name 
    FROM articles a
    LEFT JOIN users u ON a.user_id = u.id_users
    ORDER BY a.created_at DESC
");
$articles = $stmt->fetchAll();
?>

<?php include 'layout/header_admin.php'; ?>

<style>
    /* Variabel Warna */
    :root {
        --color-primary: #17a2b8;
        --color-success: #28a745;
        --color-warning: #ffc107;
        --color-danger: #dc3545;
        --color-muted: #6c757d;
        --table-header-bg: #f8f9fa;
        --table-border-color: #dee2e6;
    }

    /* --- Styling Card Statistik (Diambil dari desain sebelumnya) --- */
    .article-card {
        border-radius: 12px;
        transition: transform 0.3s ease-in-out;
        overflow: hidden;
        border: none !important;
        position: relative;
    }

    .article-card:hover {
        transform: translateY(-3px);
    }

    .card-icon-lg {
        position: absolute;
        top: 20px;
        right: 20px;
        font-size: 3rem;
        opacity: 0.1;
        color: var(--card-color, var(--color-primary));
    }

    /* --- Styling Tabel Paling Rapi (The Best) --- */
    .table-container {
        background: #ffffff;
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        /* Shadow lebih menonjol */
        overflow: hidden;
    }

    /* Header Card Tabel */
    .table-container .card-header-custom {
        padding: 1rem 1.5rem;
        background-color: #ffffff;
        border-bottom: 1px solid var(--table-border-color);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    /* Header Kolom Tabel */
    .table-articles th {
        background-color: var(--table-header-bg);
        color: var(--color-muted);
        font-weight: 700;
        text-transform: uppercase;
        font-size: 0.8rem;
        border-bottom: 2px solid var(--table-border-color);
        padding: 1rem 1.5rem;
        /* Padding lebih besar */
    }

    /* Sel Tabel */
    .table-articles td {
        vertical-align: middle;
        border-top: 1px solid #f1f1f1;
        /* Garis pemisah yang sangat halus */
        padding: 1rem 1.5rem;
        /* Padding lebih besar untuk ruang bernapas */
    }

    /* Hover Effect */
    .table-articles tbody tr:hover {
        background-color: #f7f9fc;
        /* Hover yang sangat lembut */
        cursor: pointer;
    }

    /* Style Khusus Detail Artikel */
    .article-title-detail strong {
        font-weight: 600;
        color: #343a40;
    }

    .article-title-detail small {
        display: block;
        color: var(--color-muted);
        font-size: 0.8rem;
        margin-top: 3px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        max-width: 350px;
        /* Batasi lebar deskripsi agar tidak mengganggu */
    }

    /* Style untuk Badge Status */
    .badge-status {
        padding: 0.5em 1em;
        border-radius: 50px;
        /* Bentuk pil penuh */
        font-weight: 600;
        font-size: 0.75rem;
        letter-spacing: 0.5px;
    }

    .badge-published {
        background-color: var(--color-success);
        color: white;
    }

    .badge-draft {
        background-color: var(--color-warning);
        color: #333;
    }

    .badge-deleted {
        background-color: var(--color-danger);
        color: white;
    }

    /* Tombol Aksi */
    .btn-action {
        width: 35px;
        height: 35px;
        padding: 0;
        display: inline-flex;
        justify-content: center;
        align-items: center;
        border-radius: 8px;
        /* Sudut sedikit melengkung */
        transition: background-color 0.2s;
    }

    .btn-action i {
        font-size: 0.9rem;
    }
</style>

## 📰 Articles Overview

<div class="row mb-5 g-4">
    <div class="col-lg-4 col-md-6">
        <div class="card article-card shadow-sm" style="border-left: 5px solid #28a745; --card-color: #28a745;">
            <div class="card-body">
                <i class="fas fa-check-double card-icon-lg" style="color: #28a745;"></i>
                <h6 class="card-title text-uppercase text-muted mb-2 fw-semibold">Published Articles</h6>
                <h1 class="display-5 mb-0 fw-bold"><?php echo $published_count; ?></h1>
                <p class="mt-3 mb-0 text-sm">
                    <span class="text-success me-2 fw-semibold"><i class="fas fa-arrow-up"></i> <?php echo $published_growth; ?></span>
                    <span class="text-muted text-nowrap">Growth</span>
                </p>
            </div>
        </div>
    </div>

    <div class="col-lg-4 col-md-6">
        <div class="card article-card shadow-sm" style="border-left: 5px solid #ffc107; --card-color: #ffc107;">
            <div class="card-body">
                <i class="fas fa-edit card-icon-lg" style="color: #ffc107;"></i>
                <h6 class="card-title text-uppercase text-muted mb-2 fw-semibold">Draft Articles</h6>
                <h1 class="display-5 mb-0 fw-bold"><?php echo $draft_count; ?></h1>
                <p class="mt-3 mb-0 text-sm">
                    <span class="text-warning me-2 fw-semibold"><i class="fas fa-eye"></i> <?php echo $draft_review; ?></span>
                    <span class="text-muted text-nowrap">Pending Review</span>
                </p>
            </div>
        </div>
    </div>

    <div class="col-lg-4 col-md-12">
        <div class="card article-card shadow-sm" style="border-left: 5px solid #dc3545; --card-color: #dc3545;">
            <div class="card-body">
                <i class="fas fa-trash-alt card-icon-lg" style="color: #dc3545;"></i>
                <h6 class="card-title text-uppercase text-muted mb-2 fw-semibold">Deleted Articles</h6>
                <h1 class="display-5 mb-0 fw-bold"><?php echo $deleted_count; ?></h1>
                <p class="mt-3 mb-0 text-sm">
                    <span class="text-danger me-2 fw-semibold"><i class="fas fa-arrow-down"></i> <?php echo $deleted_growth; ?></span>
                    <span class="text-muted text-nowrap">Restoration Rate</span>
                </p>
            </div>
        </div>
    </div>
</div>

---

<div class="table-container">
    <div class="card-header-custom">
        <h4 class="mb-0 fw-semibold">Daftar Artikel</h4>
        <a href="article_create.php" class="btn btn-primary d-flex align-items-center">
            <i class="fas fa-plus me-2"></i> Add New Article
        </a>
    </div>

    <?php if ($success_message): ?>
        <div class="alert alert-success alert-dismissible fade show mx-4 mt-3" role="alert">
            <?php echo $success_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table table-articles align-middle mb-0">
            <thead>
                <tr>
                    <th scope="col" style="width: 40%;">Article Detail</th>
                    <th scope="col" style="width: 15%;">Author</th>
                    <th scope="col" style="width: 15%;">Date Created</th>
                    <th scope="col" style="width: 15%;">Status</th>
                    <th scope="col" style="width: 15%;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($articles as $article): ?>
                    <tr>
                        <td class="article-title-detail">
                            <strong class="text-dark"><?php echo htmlspecialchars($article['title']); ?></strong>
                            <small class="text-muted"><?php echo htmlspecialchars($article['short_description']); ?></small>
                        </td>
                        <td><?php echo htmlspecialchars($article['author'] ?: $article['user_name'] ?: 'N/A'); ?></td>
                        <td><?php echo date('Y-m-d', strtotime($article['created_at'])); ?></td>
                        <td>
                            <?php
                            $statusClass = '';
                            if ($article['status'] == 'published') {
                                $statusClass = 'badge-published';
                            } elseif ($article['status'] == 'draft') {
                                $statusClass = 'badge-draft';
                            } else {
                                $statusClass = 'bg-secondary';
                            }
                            ?>
                            <span class="badge badge-status <?php echo $statusClass; ?>">
                                <?php echo ucfirst($article['status']); ?>
                            </span>
                        </td>
                        <td>
                            <a href="article_edit.php?id=<?php echo $article['id_articles']; ?>" class="btn btn-sm btn-info text-white btn-action me-2" title="Edit Article">
                                <i class="fas fa-pen"></i>
                            </a>
                            <form method="POST" action="article_delete.php" style="display:inline-block;">
                                <input type="hidden" name="id" value="<?php echo $article['id_articles']; ?>">
                                <button type="submit" class="btn btn-sm btn-danger btn-action" title="Delete Article" onclick="return confirm('Yakin ingin menghapus artikel: <?php echo htmlspecialchars($article['title']); ?>?');">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($articles)): ?>
                    <tr>
                        <td colspan="5" class="text-center py-5">
                            <i class="fas fa-box-open fa-3x text-light mb-3"></i>
                            <p class="mb-0 text-muted">Belum ada artikel yang tersedia.</p>
                            <a href="article_create.php" class="btn btn-outline-primary btn-sm mt-2"><i class="fas fa-plus me-1"></i> Buat Artikel Pertama Anda</a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'layout/footer_admin.php'; ?>