<?php
// File: layout/header_admin.php

// Pastikan variabel $pageTitle diatur oleh file yang memanggil
$pageTitle = $pageTitle ?? "Dashboard Admin";
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?> - BloomBelly Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        /* Desain Modern & Bersih */
        :root {
            --primary-color: #17a2b8;
            /* Teal */
            --sidebar-bg: #2c3e50;
            /* Darker Slate Gray/Midnight Blue */
            --sidebar-link-color: #ecf0f1;
            --sidebar-link-hover-bg: #34495e;
            --main-bg: #f4f6f9;
            --sidebar-width: 250px;
            /* Lebar tetap yang moderat untuk sidebar */
        }

        body {
            background-color: var(--main-bg);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
        }

        /* 1. KONTEN UTAMA: Menggunakan Flexbox Murni */
        .page-wrapper {
            display: flex;
            min-height: 100vh;
        }

        /* --- 2. Sidebar Styling (Flex Item 1) --- */
        .sidebar {
            background-color: var(--sidebar-bg);
            color: white;
            width: var(--sidebar-width);
            flex-shrink: 0;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.2);
            position: sticky;
            top: 0;
            z-index: 1000;
            padding: 1.5rem;
            display: flex;
            flex-direction: column;
        }

        .sidebar .admin-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: #fff;
            padding: 0.5rem 0 1rem 0;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 1.5rem;
        }

        .sidebar .nav-link {
            color: var(--sidebar-link-color);
            /* PERUBAHAN UTAMA: Mengurangi padding horizontal (padding-left dan padding-right) */
            padding: 0.75rem 0.5rem;
            /* Padding Vertikal tetap 0.75rem, Horizontal menjadi 0.5rem */
            margin: 0.25rem 0;
            border-radius: 5px;
            transition: background-color 0.3s, color 0.3s;
            /* Tambahkan white-space: nowrap; untuk memastikan teks tidak turun baris */
            white-space: nowrap;
        }

        .sidebar .nav-link.active {
            color: #fff;
            background-color: var(--primary-color);
            font-weight: 500;
        }

        .sidebar .nav-link:hover:not(.active) {
            color: #fff;
            background-color: var(--sidebar-link-hover-bg);
        }

        .sidebar .logout-link {
            color: #ff6b6b !important;
            margin-top: auto;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            padding-top: 1rem;
            padding-bottom: 0.5rem;
            white-space: nowrap;
            /* Terapkan juga pada Logout */
        }

        /* --- 3. Main Content Styling (Flex Item 2) --- */
        .main-content {
            flex-grow: 1;
            /* PERUBAHAN UTAMA: Mengurangi padding-top agar Header naik ke atas */
            padding: 1rem 2rem 2rem 2rem;
            /* Mengubah padding dari 2rem menjadi 1rem di atas */
        }

        .header-section {
            background-color: #fff;
            padding: 1.5rem;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            margin-bottom: 2rem;
        }

        .header-section h2 {
            font-weight: 300;
            color: #333;
            margin: 0;
        }

        .header-section .text-muted {
            font-size: 0.9rem;
        }
    </style>
</head>

<body>

    <div class="page-wrapper">

        <div class="sidebar">
            <h4 class="admin-title">BloomBelly Admin</h4>
            <nav class="nav nav-pills flex-column">
                <?php
                $currentPage = basename($_SERVER['PHP_SELF']);
                ?>

                <a class="nav-link <?php echo ($currentPage == 'dashboard.php' ? 'active' : ''); ?>" href="dashboard.php"><i class="fas fa-home me-2"></i> Dashboard</a>

                <a class="nav-link <?php echo ($currentPage == 'articles.php' || $currentPage == 'article_create.php' || $currentPage == 'article_edit.php' ? 'active' : ''); ?>" href="articles.php"><i class="fas fa-newspaper me-2"></i> Articles Management</a>

                <a class="nav-link <?php echo ($currentPage == 'forum.php' || $currentPage == 'forum_view_posts.php' ? 'active' : ''); ?>" href="forum.php"><i class="fas fa-comments me-2"></i> Management Forum</a>

                <a class="nav-link <?php echo ($currentPage == 'users.php' || $currentPage == 'user_detail.php' ? 'active' : ''); ?>" href="users.php"><i class="fas fa-users me-2"></i> Users Management</a>

                <a class="nav-link <?php echo ($currentPage == 'data_management.php' || $currentPage == 'nutrisi_create.php' || $currentPage == 'nutrisi_edit.php' ? 'active' : ''); ?>" href="data_management.php"><i class="fas fa-database me-2"></i> Management Data</a>

            </nav>
            <a class="mt-auto nav-link logout-link" href="../html/logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a>
        </div>

        <div class="main-content">
            <div class="header-section d-flex justify-content-between align-items-center">
                <h2><?php echo htmlspecialchars($pageTitle); ?></h2>
                <span class="text-muted"><i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($_SESSION['email'] ?? 'admin@bloombelly.com'); ?></span>
            </div>
            