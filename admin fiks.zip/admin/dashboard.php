<?php
// File: dashboard.php (Menggunakan Layout Global)

// 1. PANGGIL SECURITY CHECK (session_start(), cek role, dan include db)
include 'layout/security_check.php';

// 2. SET JUDUL HALAMAN
$pageTitle = "Dashboard Overview";
$admin_name = $_SESSION['name'] ?? 'Admin';
$admin_email = $_SESSION['email'] ?? 'admin@bloombelly.com';

// ==============================================================================
// 3. KODE PHP: LOGIKA DATA OVERVIEW & GRAFIK (Diperbaiki untuk 12 Bulan Penuh)
// ==============================================================================

// A. TOTAL USERS, ARTICLES, FORUM
$total_users = number_format($pdo->query("SELECT COUNT(id_users) AS total_users FROM users WHERE role = 'user'")->fetchColumn());
$total_articles = number_format($pdo->query("SELECT COUNT(id_articles) AS total_articles FROM articles WHERE status = 'published'")->fetchColumn());
$total_topics = number_format($pdo->query("SELECT COUNT(id) AS total_topics FROM forum_topics")->fetchColumn());


// --- Data Grafik Pertumbuhan Pengguna (12 bulan terakhir) ---
// 1. Ambil data mentah dari database
$stmt_growth = $pdo->query("
    SELECT 
        DATE_FORMAT(created_at, '%Y-%m') AS registration_month,
        COUNT(id_users) AS user_count
    FROM 
        users
    WHERE 
        role = 'user' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
    GROUP BY 
        registration_month
");
$raw_growth_data = $stmt_growth->fetchAll(PDO::FETCH_KEY_PAIR); // ['YYYY-MM' => count]

// 2. Siapkan array 12 bulan terakhir, inisialisasi count = 0
$labels = [];
$counts = [];
$date = new DateTime('11 months ago'); // Mulai dari 11 bulan lalu

for ($i = 0; $i < 12; $i++) {
    $month_year_key = $date->format('Y-m');
    $month_label = $date->format('M Y');

    // Ambil count dari data mentah, jika tidak ada (null), set 0
    $count = $raw_growth_data[$month_year_key] ?? 0;

    $labels[] = $month_label;
    $counts[] = $count;

    $date->modify('+1 month'); // Pindah ke bulan berikutnya
}

$json_labels = json_encode($labels);
$json_counts = json_encode($counts);


// --- Logika Persentase Pertumbuhan Bulan Ini vs Bulan Lalu (FIXED QUERY) ---
$current_month = $pdo->query("SELECT COUNT(id_users) AS count FROM users 
    WHERE role = 'user' AND DATE_FORMAT(created_at, '%Y-%m') = DATE_FORMAT(NOW(), '%Y-%m')")->fetchColumn();

$last_month = $pdo->query("SELECT COUNT(id_users) AS count FROM users 
    WHERE role = 'user' AND DATE_FORMAT(created_at, '%Y-%m') = DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 MONTH), '%Y-%m')")->fetchColumn();


$user_growth_percent = 0;
if ($last_month > 0) {
    $user_growth_percent = round((($current_month - $last_month) / $last_month) * 100);
} else if ($current_month > 0) {
    $user_growth_percent = 100;
}

$user_growth_icon = ($user_growth_percent >= 0) ? 'fa-arrow-up' : 'fa-arrow-down';
$user_growth_color = ($user_growth_percent >= 0) ? 'text-success' : 'text-danger';

// Placeholder untuk card lain
$article_growth_percent = 5;
$forum_growth_percent = 8;
?>

<?php include 'layout/header_admin.php'; ?>

<style>
    /* Mengubah Card Stats menjadi lebih visual */
    .dashboard-card {
        border-radius: 12px;
        transition: transform 0.3s ease-in-out;
        overflow: hidden;
        border: none !important;
        position: relative;
    }

    .dashboard-card:hover {
        transform: translateY(-5px);
    }

    .card-icon {
        position: absolute;
        top: 15px;
        right: 15px;
        font-size: 2.5rem;
        opacity: 0.3;
        color: var(--card-color, #0d6efd);
        /* Default color, akan ditimpa inline */
    }

    /* Styling untuk Chart Card */
    .chart-card {
        border-radius: 12px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
    }

    /* Styling Kalender */
    .calendar-placeholder {
        background-color: #ffffff;
        border: 1px solid #e9ecef;
        border-radius: 8px;
        padding: 15px;
        margin-top: 10px;
    }

    .calendar-grid {
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        gap: 2px;
        /* Jarak antar hari */
        text-align: center;
    }

    .day-name {
        font-weight: bold;
        color: #6c757d;
        font-size: 0.85rem;
    }

    .day-number {
        padding: 5px 0;
        height: 35px;
        line-height: 25px;
        cursor: default;
        transition: background-color 0.2s;
    }

    .is-today {
        background-color: #0d6efd;
        color: white;
        border-radius: 50%;
        font-weight: bold;
    }

    .empty-day {
        visibility: hidden;
    }
</style>

## 📊 Overview Statistik BloomBelly

<div class="row mb-4 g-4">
    <div class="col-lg-4 col-md-6">
        <div class="card dashboard-card shadow-sm" style="border-left: 5px solid var(--primary-color); --card-color: #0d6efd;">
            <div class="card-body">
                <i class="fas fa-users card-icon" style="color: #0d6efd;"></i>
                <h6 class="card-title text-uppercase text-muted mb-2 fw-semibold">Total Users</h6>
                <h1 class="display-5 mb-0 fw-bold"><?php echo $total_users; ?></h1>
                <p class="mt-3 mb-0 text-sm">
                    <span class="<?php echo $user_growth_color; ?> me-2 fw-semibold">
                        <i class="fas <?php echo $user_growth_icon; ?>"></i> <?php echo abs($user_growth_percent); ?>%
                    </span>
                    <span class="text-muted text-nowrap">Sejak bulan lalu</span>
                </p>
            </div>
        </div>
    </div>

    <div class="col-lg-4 col-md-6">
        <div class="card dashboard-card shadow-sm" style="border-left: 5px solid #28a745; --card-color: #28a745;">
            <div class="card-body">
                <i class="fas fa-newspaper card-icon" style="color: #28a745;"></i>
                <h6 class="card-title text-uppercase text-muted mb-2 fw-semibold">Total Articles</h6>
                <h1 class="display-5 mb-0 fw-bold"><?php echo $total_articles; ?></h1>
                <p class="mt-3 mb-0 text-sm">
                    <span class="text-success me-2 fw-semibold"><i class="fas fa-arrow-up"></i> <?php echo $article_growth_percent; ?>%</span>
                    <span class="text-muted text-nowrap">Sejak bulan lalu</span>
                </p>
            </div>
        </div>
    </div>

    <div class="col-lg-4 col-md-12">
        <div class="card dashboard-card shadow-sm" style="border-left: 5px solid #6f42c1; --card-color: #6f42c1;">
            <div class="card-body">
                <i class="fas fa-comments card-icon" style="color: #6f42c1;"></i>
                <h6 class="card-title text-uppercase text-muted mb-2 fw-semibold">Total Forum Topics</h6>
                <h1 class="display-5 mb-0 fw-bold"><?php echo $total_topics; ?></h1>
                <p class="mt-3 mb-0 text-sm">
                    <span class="text-success me-2 fw-semibold"><i class="fas fa-arrow-up"></i> <?php echo $forum_growth_percent; ?>%</span>
                    <span class="text-muted text-nowrap">Sejak bulan lalu</span>
                </p>
            </div>
        </div>
    </div>
</div>

---

## 📈 Pertumbuhan dan Aktivitas

<div class="row g-4">
    <div class="col-lg-8">
        <div class="card chart-card">
            <div class="card-header bg-white border-bottom-0 py-3">
                <h5 class="card-title mb-0 fw-semibold"><i class="fas fa-chart-line me-2 text-primary"></i> Pertumbuhan Pengguna (12 Bulan Terakhir)</h5>
            </div>
            <div class="card-body pt-0">
                <div style="height: 350px;">
                    <canvas id="userGrowthChart"></canvas>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card shadow-sm h-100">
            <div class="card-body">
                <h5 class="card-title fw-semibold"><i class="fas fa-calendar-alt me-2 text-info"></i> Kalender & Jadwal</h5>
                <div id="calendarContainer" class="calendar-placeholder">
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // --- 1. INISIALISASI GRAFIK CHART.JS ---
    const chartLabels = <?php echo $json_labels; ?>;
    const chartCounts = <?php echo $json_counts; ?>;

    if (typeof Chart !== 'undefined' && document.getElementById('userGrowthChart')) {
        const ctx = document.getElementById('userGrowthChart');

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: chartLabels,
                datasets: [{
                    label: 'Pengguna Baru',
                    data: chartCounts,
                    backgroundColor: 'rgba(13, 110, 253, 0.1)',
                    borderColor: '#0d6efd',
                    borderWidth: 2,
                    tension: 0.4,
                    fill: true,
                    pointRadius: 4, // Ukuran titik sedikit diperbesar
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        // Pastikan tooltip selalu menampilkan label Bulan/Tahun
                        callbacks: {
                            title: function(tooltipItem) {
                                return chartLabels[tooltipItem[0].dataIndex];
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Jumlah Pengguna',
                            color: '#495057'
                        },
                        ticks: {
                            // Pastikan sumbu Y menampilkan bilangan bulat
                            callback: function(value) {
                                if (value % 1 === 0) {
                                    return value;
                                }
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }


    // --- 2. INISIALISASI KALENDER SEDERHANA ---

    function renderSimpleCalendar() {
        const today = new Date();
        const currentMonth = today.getMonth();
        const currentYear = today.getFullYear();
        const todayDate = today.getDate();

        const monthNames = ["Januari", "Februari", "Maret", "April", "Mei", "Juni",
            "Juli", "Agustus", "September", "Oktober", "November", "Desember"
        ];
        const dayNames = ["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"];

        const firstDay = (new Date(currentYear, currentMonth, 1)).getDay(); // 0 (Minggu) - 6 (Sabtu)
        const daysInMonth = (new Date(currentYear, currentMonth + 1, 0)).getDate(); // Jumlah hari di bulan ini

        let calendarHTML = `
            <h6 class="text-center text-primary mb-3">${monthNames[currentMonth]} ${currentYear}</h6>
            <div class="calendar-grid mb-2">
        `;

        // Header Nama Hari
        dayNames.forEach(day => {
            calendarHTML += `<span class="day-name">${day}</span>`;
        });

        // Spasi kosong untuk hari-hari sebelum tanggal 1
        for (let i = 0; i < firstDay; i++) {
            calendarHTML += `<span class="day-number empty-day">0</span>`; // Menggunakan class CSS untuk sembunyikan
        }

        // Tanggal
        for (let day = 1; day <= daysInMonth; day++) {
            let todayClass = (day === todayDate) ? 'is-today' : '';
            calendarHTML += `
                <span class="day-number ${todayClass}">
                    ${day}
                </span>
            `;
        }

        calendarHTML += `</div>`; // Tutup calendar-grid
        calendarHTML += `<p class="small text-muted mt-3 text-center">**Catatan** Tanggal hari ini disorot.</p>`;

        // Tampilkan di container
        document.getElementById('calendarContainer').innerHTML = calendarHTML;
    }

    // Panggil fungsi kalender saat halaman dimuat
    if (document.getElementById('calendarContainer')) {
        renderSimpleCalendar();
    }
</script>

<?php include 'layout/footer_admin.php'; ?>