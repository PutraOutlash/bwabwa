<?php
session_start();
// --- Pengecekan Keamanan ---
// Pastikan path ke security_check dan db_connect sudah benar
include 'layout/security_check.php'; // Anggap file security_check.php ada di layout
include '../config/db_connect.php';

$pageTitle = "Edit Article"; // Judul halaman

$error_message = '';
$success_message = '';
$article = null;
$article_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// --- 1. Ambil Data Kategori ---
$stmt_cat = $pdo->query("SELECT id, name FROM article_categories ORDER BY name ASC");
$categories = $stmt_cat->fetchAll();

// --- 2. Proses Form Submission (UPDATE) ---
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $article_id = (int)$_POST['article_id'];
    $title = trim($_POST['title']);
    $category_id = (int)$_POST['category_id'];
    $short_description = trim($_POST['short_description']);
    $external_url = trim($_POST['external_url']);
    $author = trim($_POST['author']);
    $status = $_POST['status'];

    // Slug otomatis dari title
    $slug = strtolower(str_replace(' ', '-', $title));

    if (empty($title) || empty($short_description) || empty($external_url) || empty($author)) {
        $error_message = "Semua field wajib diisi.";
    } else {
        try {
            // Tangani tanggal publikasi
            $published_at_update = "";
            if ($status == 'published') {
                $published_at_update = ", published_at = NOW()";
            } else {
                $published_at_update = ", published_at = NULL";
            }

            // Query untuk memperbarui data artikel
            $sql = "UPDATE articles SET 
                         category_id = ?, 
                         title = ?, 
                         slug = ?, 
                         short_description = ?, 
                         external_url = ?, 
                         author = ?, 
                         status = ?
                         $published_at_update 
                    WHERE id_articles = ?";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $category_id,
                $title,
                $slug,
                $short_description,
                $external_url,
                $author,
                $status,
                $article_id
            ]);

            $success_message = "Artikel **{$title}** berhasil diperbarui!";
            header("Location: articles.php?success=updated");
            exit;
        } catch (\PDOException $e) {
            $error_message = "Gagal memperbarui data: " . $e->getMessage();
        }
    }
}

// --- 3. Ambil Data Artikel yang Akan Diedit ---
if ($article_id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM articles WHERE id_articles = ?");
    $stmt->execute([$article_id]);
    $article = $stmt->fetch();

    if (!$article) {
        $error_message = "Artikel tidak ditemukan.";
    }
} else if ($_SERVER["REQUEST_METHOD"] != "POST") {
    header("Location: articles.php");
    exit;
}

// Jika terjadi error saat POST, gunakan data POST yang sudah ada
$data_to_display = $article;
if ($_SERVER["REQUEST_METHOD"] == "POST" && $article) {
    $data_to_display = $_POST;
    $data_to_display['id_articles'] = $article_id;
}
?>

<?php
// SET JUDUL HALAMAN (sudah di atas)
include 'layout/header_admin.php';
?>

<style>
    /* Form Styling */
    .form-card {
        border-radius: 12px;
        border: 1px solid #e9ecef;
    }

    .form-label {
        font-weight: 600;
        color: #343a40;
        margin-bottom: 0.5rem;
    }

    .form-control,
    .form-select,
    .form-text {
        border-radius: 8px;
    }

    .form-control:focus,
    .form-select:focus {
        border-color: var(--primary-color);
        box-shadow: 0 0 0 0.25rem rgba(23, 162, 184, 0.25);
    }
</style>

<div class="header-section">
    <h2><i class="fas fa-pen-nib me-2 text-primary"></i> Edit Artikel: <?php echo htmlspecialchars($data_to_display['title'] ?? 'N/A'); ?></h2>
    <a href="articles.php" class="btn btn-outline-secondary d-flex align-items-center">
        <i class="fas fa-arrow-left me-2"></i> Kembali ke Daftar Artikel
    </a>
</div>

<div class="card form-card shadow-sm">
    <div class="card-body p-4 p-md-5">

        <?php if ($error_message): ?>
            <div class="alert alert-danger fade show" role="alert"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <?php if ($success_message): ?>
            <div class="alert alert-success fade show" role="alert"><?php echo $success_message; ?></div>
        <?php endif; ?>

        <?php if (!$article && $_SERVER["REQUEST_METHOD"] != "POST"): ?>
            <div class="alert alert-warning">ID Artikel tidak valid atau tidak ditemukan.</div>
        <?php else: ?>

            <form method="POST" action="article_edit.php?id=<?php echo $data_to_display['id_articles']; ?>">
                <input type="hidden" name="article_id" value="<?php echo $data_to_display['id_articles']; ?>">

                <div class="mb-4">
                    <label for="title" class="form-label">Judul Artikel <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="title" name="title" required value="<?php echo htmlspecialchars($data_to_display['title'] ?? ''); ?>" placeholder="Masukkan judul artikel yang jelas">
                </div>

                <div class="row">
                    <div class="col-md-6 mb-4">
                        <label for="category_id" class="form-label">Kategori <span class="text-danger">*</span></label>
                        <select class="form-select" id="category_id" name="category_id" required>
                            <option value="">Pilih Kategori</option>
                            <?php foreach ($categories as $cat): ?>
                                <?php
                                $selected = ($cat['id'] == ($data_to_display['category_id'] ?? 0)) ? 'selected' : '';
                                ?>
                                <option value="<?php echo $cat['id']; ?>" <?php echo $selected; ?>>
                                    <?php echo htmlspecialchars($cat['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-4">
                        <label for="status" class="form-label">Status <span class="text-danger">*</span></label>
                        <select class="form-select" id="status" name="status" required>
                            <?php
                            $current_status = $data_to_display['status'] ?? 'draft';
                            ?>
                            <option value="draft" <?php echo ($current_status == 'draft' ? 'selected' : ''); ?>>Draft (Belum Publik)</option>
                            <option value="published" <?php echo ($current_status == 'published' ? 'selected' : ''); ?>>Published (Sudah Publik)</option>
                        </select>
                    </div>
                </div>

                <div class="mb-4">
                    <label for="author" class="form-label">Nama Penulis <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="author" name="author" required value="<?php echo htmlspecialchars($data_to_display['author'] ?? ''); ?>" placeholder="Contoh: Dr. Maya">
                    <small class="form-text text-muted">Nama yang akan ditampilkan sebagai penulis.</small>
                </div>

                <div class="mb-4">
                    <label for="external_url" class="form-label">External URL (Sumber Asli) <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-link"></i></span>
                        <input type="url" class="form-control" id="external_url" name="external_url" required value="<?php echo htmlspecialchars($data_to_display['external_url'] ?? ''); ?>" placeholder="https://example.com/artikel-sumber">
                    </div>
                    <small class="form-text text-muted">Link ke sumber artikel eksternal.</small>
                </div>

                <div class="mb-5">
                    <label for="short_description" class="form-label">Deskripsi Singkat <span class="text-danger">*</span></label>
                    <textarea class="form-control" id="short_description" name="short_description" rows="5" required placeholder="Tuliskan ringkasan singkat artikel (maksimal 2-3 baris)."><?php echo htmlspecialchars($data_to_display['short_description'] ?? ''); ?></textarea>
                </div>

                <button type="submit" class="btn btn-primary btn-lg d-flex align-items-center">
                    <i class="fas fa-save me-2"></i> Simpan Perubahan
                </button>
            </form>

        <?php endif; ?>
    </div>
</div>

<?php
// Perlu asumsi ada file footer_admin.php di layout, yang berisi </div></div></body></html>
include 'layout/footer_admin.php';
?>