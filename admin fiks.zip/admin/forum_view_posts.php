<?php
// File: forum_view_posts.php
// Menampilkan semua postingan/komentar dalam satu topik untuk moderasi.

// --- PANGGIL SECURITY CHECK dan DB CONNECT (seharusnya sudah menangani session_start()) ---
include 'layout/security_check.php';

$topic_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$topic = null;
$posts = [];
$error_message = '';
$success_message = '';

if (isset($_GET['success']) && $_GET['success'] == 'post_deleted') {
    $success_message = 'Komentar berhasil dihapus! 🗑️';
}

if ($topic_id > 0) {
    try {
        // --- 1. Ambil Detail Topik ---
        $stmt_topic = $pdo->prepare("SELECT id, title FROM forum_topics WHERE id = ?");
        $stmt_topic->execute([$topic_id]);
        $topic = $stmt_topic->fetch();

        if (!$topic) {
            $error_message = "Topik tidak ditemukan.";
        } else {
            // --- 2. Ambil Semua Postingan dalam Topik (Termasuk post awal) ---
            $stmt_posts = $pdo->prepare("
                SELECT 
                    p.id AS post_id, 
                    p.content, 
                    p.created_at, 
                    u.name AS user_name,
                    u.id_users AS user_id
                FROM forum_posts p
                JOIN users u ON p.user_id = u.id_users
                WHERE p.topic_id = ?
                ORDER BY p.created_at ASC
            ");
            $stmt_posts->execute([$topic_id]);
            $posts = $stmt_posts->fetchAll();
        }
    } catch (\PDOException $e) {
        $error_message = "Gagal mengambil data: " . $e->getMessage();
    }
} else {
    $error_message = "ID Topik tidak valid.";
}

$pageTitle = $topic ? "Moderasi Post: " . htmlspecialchars($topic['title']) : "Moderasi Postingan Forum";
?>

<?php include 'layout/header_admin.php'; ?>

<style>
    /* Variabel Warna */
    :root {
        --color-primary: #17a2b8;
        /* Teal */
        --color-starter: #28a745;
        /* Hijau */
        --color-comment: #007bff;
        /* Biru */
    }

    /* Post Card Styling */
    .post-card-wrapper {
        background: #ffffff;
        border-radius: 12px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        margin-bottom: 1.5rem;
        padding: 1.5rem;
    }

    /* Indikator Visual Kiri */
    .post-indicator {
        width: 6px;
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        border-radius: 12px 0 0 12px;
    }

    .post-starter .post-indicator {
        background-color: var(--color-starter);
        /* Hijau untuk Starter */
    }

    .post-comment .post-indicator {
        background-color: var(--color-comment);
        /* Biru untuk Komentar */
    }

    /* Post Content Styling */
    .post-meta small {
        font-size: 0.75rem;
    }

    .post-meta h6 {
        font-size: 1rem;
        font-weight: 600;
        margin-top: 0.3rem;
    }

    .post-content {
        margin-top: 1rem;
        padding-top: 1rem;
        border-top: 1px dashed #e9ecef;
        /* Garis pemisah konten yang halus */
        font-size: 0.95rem;
        color: #495057;
    }

    /* Tombol Aksi */
    .btn-action {
        width: 35px;
        height: 35px;
        padding: 0;
        display: inline-flex;
        justify-content: center;
        align-items: center;
        border-radius: 8px;
    }
</style>

<?php if ($error_message): ?>
    <div class="alert alert-danger fade show mb-4"><?php echo $error_message; ?></div>
<?php endif; ?>

<?php if ($success_message): ?>
    <div class="alert alert-success alert-dismissible fade show mb-4" role="alert">
        <?php echo $success_message; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<?php if ($topic): ?>

    <div class="header-section mb-4">
        <h2><i class="fas fa-eye me-2 text-primary"></i> Moderasi Postingan Topik</h2>
        <a href="forum.php" class="btn btn-outline-secondary d-flex align-items-center">
            <i class="fas fa-arrow-left me-2"></i> Kembali ke Daftar Topik
        </a>
    </div>

    <div class="card shadow-sm mb-5">
        <div class="card-body bg-light rounded p-4">
            <h4 class="mb-1 text-dark">Topik: <strong><?php echo htmlspecialchars($topic['title']); ?></strong></h4>
            <p class="text-muted mb-0"><i class="fas fa-layer-group me-1"></i> Total Postingan: <?php echo count($posts); ?></p>
        </div>
    </div>

    <div class="posts-list">
        <?php
        $post_counter = 0;
        foreach ($posts as $post):
            $post_counter++;
            $is_first_post = ($post_counter == 1);
            $card_class = $is_first_post ? 'post-starter' : 'post-comment';
        ?>
            <div class="post-card-wrapper <?php echo $card_class; ?> position-relative">
                <div class="post-indicator"></div>
                <div class="d-flex justify-content-between align-items-center">
                    <div class="post-meta">
                        <small class="text-muted d-block">
                            <i class="fas fa-user-circle me-1"></i>
                            Oleh: <strong class="text-dark"><?php echo htmlspecialchars($post['user_name']); ?></strong>
                            (ID: <?php echo $post['user_id']; ?>)
                        </small>
                        <small class="text-muted d-block">
                            <i class="far fa-clock me-1"></i> <?php echo date('d M Y, H:i', strtotime($post['created_at'])); ?>
                        </small>
                    </div>

                    <div class="flex-shrink-0 d-flex align-items-center">
                        <?php if ($is_first_post): ?>
                            <span class="badge bg-success me-3 p-2 fw-semibold">TOPIC STARTER</span>
                        <?php else: ?>
                            <span class="badge bg-primary me-3 p-2 fw-semibold">KOMENTAR</span>
                        <?php endif; ?>

                        <form method="POST" action="forum_delete_post.php" style="display:inline-block;">
                            <input type="hidden" name="post_id" value="<?php echo $post['post_id']; ?>">
                            <input type="hidden" name="topic_id" value="<?php echo $topic_id; ?>">
                            <button type="submit"
                                class="btn btn-sm btn-danger btn-action"
                                title="Hapus Postingan Ini"
                                onclick="return confirm('Yakin ingin menghapus postingan ini? Tindakan ini tidak dapat dibatalkan.');">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </form>
                    </div>
                </div>

                <div class="post-content">
                    <?php echo nl2br(htmlspecialchars($post['content'])); ?>
                </div>

            </div>
        <?php endforeach; ?>
    </div>

    <?php if (empty($posts)): ?>
        <div class="alert alert-info text-center py-4">
            <i class="fas fa-box-open fa-2x mb-2"></i>
            <p class="mb-0">Topik ini belum memiliki postingan/komentar.</p>
        </div>
    <?php endif; ?>

<?php endif; ?>

<?php include 'layout/footer_admin.php'; ?>